package com.hibay.crrcgc.ve.ut.sql;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.dl.location.util.StringUtil;
import com.dl.location.util.ToStringUtil;

public class SqlDataGenerator {
	
	public static void main(String[] args) {
		StringBuilder builder = new StringBuilder();
		//dataObjectToSql(builder, order);
		System.out.println(builder);
	}
	
	public static void dataObjectListToSql(StringBuilder builder, List<?> objList) {
		for (Object obj : objList) 
			dataObjectToSql(builder, obj);
	}
	
	
	public static void dataObjectToSql(StringBuilder builder, Object obj) {
		List<String> sqlTokenList = new ArrayList<String>();
		Class<?> cls = obj.getClass();
		String tableName = ToStringUtil.printWithDelimiter(cls.getSimpleName());
		builder.append("INSERT INTO " + tableName + " SET \n");
		try {
			for (Method method : cls.getDeclaredMethods()) {
				if (!method.getName().startsWith("set"))
					continue;
				Class<?>[] parameterTypes = method.getParameterTypes();
				if (parameterTypes.length != 1)
					continue;
				
				for (Class<?> parameterType : parameterTypes) {
					if (parameterType.getCanonicalName().toLowerCase().contains("hibay")) {
						if (!parameterType.isEnum())
							continue;
					}
					setEnumIntLongStringDoubleBoolean(sqlTokenList, obj, method, parameterType);
				}
			}
			builder.append(StringUtil.join(sqlTokenList, ",\n"));
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		builder.append(";\n");
	
	}
	
	private static void setEnumIntLongStringDoubleBoolean(
			List<String> sqlTokenList, Object obj, Method method, Class<?> parameterType) throws Exception {
		String columnName = method.getName().substring(3);
		columnName = columnName.substring(0, 1).toLowerCase() + columnName.substring(1);
		String getterMethodName = "get" + method.getName().substring(3);
		Method getterMethod = obj.getClass().getDeclaredMethod(getterMethodName);
		Object value = getterMethod.invoke(obj);
		sqlTokenList.add(" " + columnName + " = '" + value + "'");
	}
	
}
