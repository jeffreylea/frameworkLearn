package com.dl.location.util;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class MiscUtil {
	
	public static boolean isEmpty(List<?> list) {
		return (list == null || list.size() == 0);
	}
	
	public static boolean isNotEmpty(List<?> list) {
		return (list != null && list.size() != 0);
	}

	public static void sleep(long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
    public static void wait(Object obj, long milliseconds) {
        try {
            obj.wait(milliseconds); //If obj is null, just thrown NullPointerException
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
	
    public static Object invoke(Method method, Object obj, Object[] parameters) {
        try {
            return method.invoke(obj, parameters);
        }
        catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public static void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        }
        catch (InterruptedException e) {
        }
    }
    
    public static void close(Socket socket) {
        try {
            if (socket != null)
                socket.close();
        }
        catch (IOException e) {
        }
    }

    public static void close(ServerSocket serverSocket) {
        try {
            if (serverSocket != null)
                serverSocket.close();
        }
        catch (IOException e) {
        }
    }
    
    public static void close(Closeable closeable) {
        try {
            if (closeable != null)
                closeable.close();
        }
        catch (IOException e) {
        }
    }
    
}
