package com.dl.location.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ToStringUtil {
    
	public static String printWithDelimiter(String str) {
		Pattern p = Pattern.compile("\\s*|\t|\r|\n");      
        Matcher m = p.matcher(str);      
        str = m.replaceAll(""); 
        
		//Print "myDataObjectString" to "my_data_object_string"
		StringBuilder builder = new StringBuilder();
		boolean isPreviousCharacterLowerCase = false;
		for (char c : str.toCharArray()) {
			if (Character.isLowerCase(c)) {
				builder.append(c);
				isPreviousCharacterLowerCase = true;
			}
			else {
				if (isPreviousCharacterLowerCase)
					builder.append("_").append(Character.toLowerCase(c));
				else
					builder.append(Character.toLowerCase(c));
				isPreviousCharacterLowerCase = false;
			}
		}
		
		return builder.toString();
	}
	
	public static String printPretty(Object obj) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(obj);
		return json;
	}
	
    public static String getHostAddress(String hostName) {
        try {
            InetAddress address = InetAddress.getByName(hostName);
            return address.getHostAddress();
        }
        catch (Exception e) {
            return hostName;
        }
    }
    
    public static String getSocketHostName(SocketAddress socket) { 
        String remoteHost = ((InetSocketAddress) socket).getAddress().getHostName();
        return remoteHost;
    }
    
    public static String getSocketHostAddress(SocketAddress socket) { 
        String remoteHost = ((InetSocketAddress) socket).getAddress().getHostAddress();
        return remoteHost;
    }
    
    public static int getSocketPort(SocketAddress socket) { 
        int remotePort = ((InetSocketAddress) socket).getPort();
        return remotePort;
    }
    
    public static String getServerSocketKey(SocketAddress socket) {
    	int remotePort = ((InetSocketAddress) socket).getPort();
    	String remoteHost = ((InetSocketAddress) socket).getAddress().getHostAddress();
    	return getServerSocketKey(remoteHost, remotePort);
    }
    
    public static String getServerSocketKey(String ip, int port) {
    	return (new StringBuffer()).append(ip).append(":").append(port).toString();
    }
    
    public static String getHostPart(String hostColonPort) {
        if (hostColonPort == null)
            return null;
        int colonIndex = hostColonPort.indexOf(":");
        if (colonIndex == -1)
            return null;
        return hostColonPort.substring(0, colonIndex);
        
    }
    public static int getPortPart(String hostColonPort) {
        int invalidPort = -1;
        if (hostColonPort == null)
            return invalidPort;
        int colonIndex = hostColonPort.indexOf(":");
        if (colonIndex == -1)
            return invalidPort;
        String portValue = hostColonPort.substring(colonIndex + 1);
        return Integer.valueOf(portValue);
    }
 
    public static String generateHexString(short b) {
        return (String.format("%04x", b));
    }
    
    public static String generateHexString(int b) {
        return (String.format("%08x", b));
    }
    
    public static String generateHexString(byte b) {
        return (String.format("%02x", b));
    }
    
    public static String generateHexString(byte[] bytes) {
        if (DataValidator.isEmpty(bytes))
            return null;
        return dump(bytes, bytes.length);
    }
    
    public static byte[] generateByteArray(String hex) {
        int index = 0;
        int size = hex.length()/2;
        byte[] g = new byte[size];
        int loc = 0;
        
        while(loc < g.length) {
            char o = hex.charAt(index++);
            char c = hex.charAt(index++);
            
            g[loc++] = (byte)((charToByte(o) << 4) | charToByte(c));
        }
        return g;
    }
    
    private static byte charToByte(char c) {
        switch (c) {
        case '0': return 0;
        case '1': return 1;
        case '2': return 2;
        case '3': return 3;
        case '4': return 4;
        case '5': return 5;
        case '6': return 6;
        case '7': return 7;
        case '8': return 8;
        case '9': return 9;
        case 'a':
        case 'A': return 10;
        case 'b':
        case 'B': return 11;
        case 'c':
        case 'C': return 12;
        case 'd':
        case 'D': return 13;
        case 'e':
        case 'E': return 14;
        case 'f':
        case 'F': return 15;
        }
        return 0;
    }

    public static String dump(byte[] buffer, int length) {
        if (DataValidator.isEmpty(buffer))
            return null;
        if (length > buffer.length)
            length = buffer.length;
       
        StringBuffer buf = new StringBuffer(50);
        for (int i = 0; i < length; i++) {
            buf.append(String.format("%02x", buffer[i]));
        }
        return buf.toString();
    }
    
    public static String translateToString(byte[] b, int dataSize) throws IOException {
    	if(b != null) {
    		ByteArrayInputStream bais = new ByteArrayInputStream(b, 0, dataSize);
    		DataInputStream dis = new DataInputStream(bais);
    		BufferedReader bfr = new BufferedReader(new InputStreamReader(dis));

    		String vS = bfr.readLine();
    		bfr.close();
    		dis.close();

    		return vS;
    	}
    	else {
    		return null;
    	}
    }

    public static String toString(byte[] byteArr) {
        return dump(byteArr);
    }

    public static String dump(byte[] byteArr) {
        return dump(byteArr, byteArr.length);
    }

    public static StringBuffer printArray(Object[] list) {
        StringBuffer printBuf = new StringBuffer();
        printBuf.append("Array[] = \n");
        if (list == null || list.length == 0)
            printBuf.append("NULL \n");
        else {
            for (int i = 0; i < list.length; i++)
                printBuf.append("\t Array[").append(i).append("] = ").append(list[i]).append("\n");
        }
        return printBuf;
    }

    public static String printArray(String[] list) {
        StringBuffer printBuf = new StringBuffer();
        printBuf.append("[ ");

        if (list == null || list.length == 0)
            printBuf.append("NULL ");
        else {
            for (int i = 0; i < list.length; i++)
                printBuf.append(list[i]).append(" ");
        }
        printBuf.append("]");
        return printBuf.toString();
    }

    public static StringBuffer printList(String... list) {
        StringBuffer printBuf = new StringBuffer();
        printBuf.append("List<?> = \n");
        if (list == null || list.length == 0)
            printBuf.append("NULL \n");
        else {
            for (int i = 0; i < list.length; i++)
                printBuf.append("\t List[").append(i).append("] = ").append(list[i]).append("\n");
        }
        return printBuf;
    }

    public static StringBuffer printList(List<?> list) {
        StringBuffer printBuf = new StringBuffer();
        printBuf.append("List<?> = \n");
        if (list == null || list.size() == 0)
            printBuf.append("NULL \n");
        else {
            printBuf.append("List.size = " + list.size());
            int printLength = list.size() > 20 ? 20 : list.size();
            for (int i = 0; i < printLength; i++)
                printBuf.append("\t List[").append(i).append("] = ").append(list.get(i)).append("\n");
        }
        return printBuf;
    }

    public static StringBuffer printMap(String hashName, Map<?, ?> map) {
        StringBuffer sb = new StringBuffer();
        sb.append("\n -------- Map Begins : ").append(hashName).append(" --------");
        if (map == null || map.size() == 0)
            sb.append("\n NULL \n");
        else {
            sb.append("map.size = " + map.size());
            int printLength = map.size() > 20 ? 20 : map.size();
            synchronized (map) {
                Iterator<?> iterator = map.keySet().iterator();
                while (iterator.hasNext() && printLength >= 0) {
                    printLength--;
                    Object key = iterator.next();
                    Object value = map.get(key);
                    if (key instanceof byte[])
                        sb.append("\n KEY   = ").append(toString((byte[]) key));
                    else
                        sb.append("\n KEY   = ").append(key);
                    sb.append("\n VALUE = ").append(value == null ? "null" : value.toString());
                }
            }
        }
        sb.append("\n -------- Map Ends : ").append(hashName).append(" --------");
        return sb;
    }

    public static String getNonNullString(Object o) {
        return o == null ? "" : String.valueOf(o);
    }
    
}
