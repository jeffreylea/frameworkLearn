package com.dl.location.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dl.location.api.ApiValue;
import com.dl.location.util.RestfulUtil;
import com.dl.location.util.SmsUtil;
import com.dl.location.util.ToStringUtil;

@Component
public class ExpenseAccountFacade {
	
	/*
	@Autowired
	private ExpenseAccountService service;
	@Autowired
	private ExpenseAuditorService auditorService;
	@Autowired
	private UserSessionService userService;
	@Autowired
	private UserProfileDao userDao;

	protected static final Logger logger = LoggerFactory
			.getLogger(ExpenseAccountFacade.class);

	public ApiValue<VeExpenseAccount> addExpenseAccount(
			VeExpenseAccount expenseAccount) {
		try {
			logger.info("ExpenseAccountFacade.addExpenseAccount input VeExpenseAccount "
					+ ToStringUtil.printPretty(expenseAccount));
			service.addExpenseAccount(expenseAccount);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountFacade.addExpenseAccount RuntimeException "
							+ e, e);
			e.printStackTrace();
		} finally {
			logger.info("ExpenseAccountFacade.addExpenseAccount output Customer "
					+ ToStringUtil.printPretty(expenseAccount));
		}
		return new ApiValue<VeExpenseAccount>(expenseAccount);
	}

	public ApiValue<VeExpenseAccount> getExpenseAccount(int id) {
		VeExpenseAccount expenseAccount = null;
		try {
			expenseAccount = service.getExpenseAccount(id);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccount RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<VeExpenseAccount>(expenseAccount);
	}
	
	public List<VeExpenseAuditor> getExpenseAuditorByExpenseId(int expenseAccountId) {
		List<VeExpenseAuditor> auditorList = null;
		try {
			auditorList = auditorService.getExpenseAuditorByExpenseId(expenseAccountId);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAuditorByRole RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return auditorList;
	}
	
	public ApiValue<Map<String, Object>> getExpenseAccountList(String userId,
			VeUserRoleEnum role, int page) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<VeExpenseAccount> expenseAccountList = null;
		int totalPages = 0;
		try {
			expenseAccountList = service.getExpenseAccountList(userId, role,
					page);
			totalPages = service.getExpenseAccountListCount(userId, role);
			map.put("totalPages", totalPages);
			map.put("list", expenseAccountList);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountList RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<Map<String, Object>>(map);
	}

	public ApiValue<Map<String, Object>> getExpenseAccountListByStatus(
			VeExpenseStatusEnum status, String userId, VeUserRoleEnum role,
			int page) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<VeExpenseAccount> expenseAccountList = null;
		int totalPages = 0;
		try {
			expenseAccountList = service.getExpenseAccountListByStatus(status,
					userId, role, page);
			totalPages = service.getExpenseAccountListCountByStatus(status,
					userId, role);
			map.put("totalPages", totalPages);
			map.put("list", expenseAccountList);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountListByStatus RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<Map<String, Object>>(map);
	}

	public ApiValue<List<VeExpenseAccount>> getExpenseAccountListByVehicleNum(
			String vehicleNum) {
		List<VeExpenseAccount> expenseAccountList = null;
		try {
			expenseAccountList = service
					.getExpenseAccountListByVehicleNum(vehicleNum);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountListByVehicleNum RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<List<VeExpenseAccount>>(expenseAccountList);
	}

	public ApiValue<Map<String, Object>> getExpenseAccountListByCreateDate(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, String userId,
			VeUserRoleEnum role, int page) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<VeExpenseAccount> expenseAccountList = null;
		int totalPages = 0;
		try {
			expenseAccountList = service.getExpenseAccountListByCreateDate(
					beginDate, endDate, userId, role, page);
			totalPages = service.getExpenseAccountListCountByCreateDate(
					beginDate, endDate, userId, role);
			map.put("totalPages", totalPages);
			map.put("list", expenseAccountList);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountListByCreateDate RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<Map<String, Object>>(map);
	}

	public ApiValue<Map<String, Object>> getExpenseAccountListByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role, @Param("page") int page) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<VeExpenseAccount> expenseAccountList = null;
		int totalPages = 0;
		try {
			expenseAccountList = service
					.getExpenseAccountListByStatusAndCreateDate(status,
							beginDate, endDate, userId, role, page);
			totalPages = service
					.getExpenseAccountListCountByStatusAndCreateDate(status,
							beginDate, endDate, userId, role);
			map.put("totalPages", totalPages);
			map.put("list", expenseAccountList);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountListByStatusAndCreateDate RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<Map<String, Object>>(map);
	}

	public ApiValue<VeExpenseAccount> updateExpenseAccount(
			@Param("expenseAccount") VeExpenseAccount expenseAccount) {
		try {
			expenseAccount = service.updateExpenseAccount(expenseAccount);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.updateExpenseAccount RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<VeExpenseAccount>(expenseAccount);
	}
	
	public ApiValue<VeExpenseAccount> submitExpenseAccount(
			@Param("expenseAccount") VeExpenseAccount expenseAccount) {
		try {
			service.commit(expenseAccount.getSubmitterId(), expenseAccount.getCurrentAuditor(), expenseAccount.getId());
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.submitExpenseAccount RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<VeExpenseAccount>(expenseAccount);
	}

	public ApiValue<String> getLatestSn(@Param("currentDay") String currentDay) {
		String sn = currentDay + "0001";
		try {
			sn = service.getLatestSn(currentDay);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.updateExpenseAccount RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<String>(sn);
	}

	public double getSumAmountBySubmitter(String userId, VeUserRoleEnum role,
			VeExpenseStatusEnum status) {
		return service.getSumAmountBySubmitter(userId, role, status);
	}
	
	public double getSumAmountBySubmitter(ExpenseSearchVo expenseSearchVo) {
		logger.info("expenseSearchVo.start:"+expenseSearchVo.getStart()+"; count:"+expenseSearchVo.getCount());
		return service.getSumAmountBySubmitter(expenseSearchVo);
	}

	public double getSumAmountAll(VeExpenseStatusEnum status) {
		return service.getSumAmountAll(status);
	}
	
	public double getSumAmountAll(ExpenseSearchVo expenseSearchVo) {
		return service.getSumAmountAll(expenseSearchVo);
	}

	public double getSumAmountByAuditor(String auditorId, VeUserRoleEnum role,
			VeExpenseStatusEnum status) {
		return service.getSumAmountByAuditor(auditorId, role, status);
	}
	
	public double getSumAmountByAuditor(ExpenseSearchVo expenseSearchVo) {
		return service.getSumAmountByAuditor(expenseSearchVo);
	}

	public void audit(int expenseId, String fromAuditorId, String toAuditorId,
			int role, int type, String comments) {
		service.audit(fromAuditorId, toAuditorId, expenseId, type, role,
				comments);
	}

	public ApiValue<Map<String, Object>> filterExpenseAccount(
			ExpenseSearchVo expenseSearchVo) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<VeExpenseAccount> expenseAccountList = null;
		int totalPages = 0;
		try {
			expenseAccountList = service.filterExpenseAccount(expenseSearchVo);
			totalPages = service.countExpenseAccount(expenseSearchVo);
			map.put("totalPages", totalPages);
			map.put("list", expenseAccountList);
		} catch (RuntimeException e) {
			logger.error(
					"ExpenseAccountService.getExpenseAccountListByStatusAndCreateDate RuntimeException "
							+ e, e);
			e.printStackTrace();
		}
		return new ApiValue<Map<String, Object>>(map);
	}

	public String getMobileByExpenseAccount(VeExpenseAccount expenseAccount){
		String userId = expenseAccount.getEmployeeId();
		UserProfile user = userDao.getUserProfile(userId);
		if(user!=null){
			String mobile = user.getCellPhoneNumber();
			return mobile;
		}else{
			return null;
		}
	}
	*/
}
