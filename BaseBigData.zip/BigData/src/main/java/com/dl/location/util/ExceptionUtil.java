package com.dl.location.util;

import java.io.CharArrayWriter;
import java.io.PrintWriter;

public class ExceptionUtil {

    public static String getStackTrace(Exception e) {
        if (e instanceof java.io.IOException)
            return e.getMessage();
        else if (e instanceof java.security.PrivilegedActionException)
            return e.getMessage();
        return getStackTraceThrowable(e);
    }

    private static String getStackTraceThrowable(Throwable e) {
        CharArrayWriter cout = new CharArrayWriter();
        PrintWriter writer = new PrintWriter(cout);
        writer.println(e);
        StackTraceElement[] trace = e.getStackTrace();
        for (int i=0; i < trace.length; i++) {
            if (trace[i].getClassName().startsWith("com.hibay"))
                writer.println("\t@ " + trace[i]);
        }

        Throwable ourCause = e.getCause();
        if (ourCause != null)
            writer.println(getStackTraceThrowable(ourCause));

        return cout.toString();
    }
}
