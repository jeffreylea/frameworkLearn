package com.dl.location.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Md5Utils {
	
	public static String encode(String input) {
	    try {
	    	MessageDigest md5 = MessageDigest.getInstance("MD5");
	        byte[] byteArray = input.getBytes("UTF-8");
		    byte[] md5Bytes = md5.digest(byteArray);
		    StringBuffer hexValue = new StringBuffer();
		    for (int i = 0; i < md5Bytes.length; i++) {
		        int val = ((int) md5Bytes[i]) & 0xff;
		        if (val < 16) {
		            hexValue.append("0");
		        }
		        hexValue.append(Integer.toHexString(val));
		    }
		    return hexValue.toString();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return null;
	}
	
	public static String encode32(String input) {
	    try {
	    	MessageDigest md5 = MessageDigest.getInstance("MD5");
	        byte[] byteArray = input.getBytes("UTF-8");
		    byte[] md5Bytes = md5.digest(byteArray);
		    StringBuffer hexValue = new StringBuffer();
		    for (int i = 0; i < md5Bytes.length; i++) {
		        int val = ((int) md5Bytes[i]) & 0xff;
		        if (val < 16) {
		            hexValue.append("0");
		        }
		        hexValue.append(Integer.toHexString(val));
		    }
		    return hexValue.toString();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return null;
	}
	
	public static String encode16(String input) {
	    try {
	    	MessageDigest md5 = MessageDigest.getInstance("MD5");
	        byte[] byteArray = input.getBytes("UTF-8");
		    byte[] md5Bytes = md5.digest(byteArray);
		    StringBuffer hexValue = new StringBuffer();
		    for (int i = 0; i < md5Bytes.length; i++) {
		        int val = ((int) md5Bytes[i]) & 0xff;
		        if (val < 16) {
		            hexValue.append("0");
		        }
		        hexValue.append(Integer.toHexString(val));
		    }
		    String ret = hexValue.toString();
		    if(ret.length()>24){
		    	return ret.substring(8, 24);
		    }else{
		    	return null;
		    }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return null;
	}
	
	private static String MD5(String sourceStr) {
        String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(sourceStr.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString();
            System.out.println("MD5(" + sourceStr + ",32) = " + result);
            System.out.println("MD5(" + sourceStr + ",16) = " + buf.toString().substring(8, 24));
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
        }
        return result;
    }
	
	public static void main(String[] args) {
		System.out.println(encode32("南车"));
		System.out.println(encode16("南车"));
		System.out.println(encode16("南车"+encode32("000000")+"2016-06-01 16:10:00"));
		
		MD5("南车670b14728ad9902aecba32e22fa4f6bd2016-06-01 16:10:00");
		
	}
}
