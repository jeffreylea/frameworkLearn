package com.dl.location.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

public class StringUtil {

    public static String trim(String inCheck) {
        if (isEmpty(inCheck))
            return null;
        return inCheck.trim();
    }
    
    public static int getStringTrimLength(String inCheck) {
        if (isEmpty(inCheck))
            return 0;
        inCheck = inCheck.trim();
        return inCheck.length();
    }

    public static boolean isEmpty(String string) {
        if (string == null)
            return true;
        return (string.trim().length() == 0);
    }

    public static boolean equalsWithNull(String s1, String s2) {
        if (s1 == s2)
            return true;
        if (s1 == null)
            return (s2 == null);
        if (s2 == null)
            return (s1 == null);
        return s1.equals(s2);
    }

    public static boolean equalsIgnoreCaseWithNull(String s1, String s2) {
        if (s1 == s2)
            return true;
        if (s1 == null)
            return (s2 == null);
        if (s2 == null)
            return (s1 == null);
        return s1.toLowerCase().equals(s2.toLowerCase());
    }
    
    public static int parseInt(String inInt, int inDefault) {
        try {
            if (inInt == null)
                return inDefault;
            return Integer.parseInt(inInt);
        }
        catch (Exception e) {
            return inDefault;
        }
    }

    public static List<String> splitToList(String string, String delimiter) {
    	List<String> vector = new ArrayList<String>();
        if (string == null || delimiter == null)
            return vector;

        try {
            int iSlen = string.length();
            int iCurPos = 0;
            int iDelLen = delimiter.length();
            while ((iCurPos != -1) && (iCurPos < iSlen)) {
                iCurPos = string.indexOf(delimiter, iCurPos);
                if ((iCurPos == 0) && (iCurPos + iDelLen >= iSlen))
                    break;
                else if (iCurPos > 0) {
                    String temp = string.substring(0, iCurPos);
                    vector.add(temp);
                }
                if ((iCurPos != -1) && (iCurPos + iDelLen <= iSlen)) {
                    string = string.substring(iCurPos + iDelLen);
                    iSlen = string.length();
                    iCurPos = 0;
                }
            }

            if ((iCurPos == -1) && (string.length() > 0))
                vector.add(string);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return vector;
    }

    public static String join(List<String> list, String delim) {
        StringBuffer res = new StringBuffer();
        boolean first = true;
        for (String string : list) {
            if (first)
                first = false;
            else
                res.append(delim);
            res.append(string);
        }
        return res.toString();
    }
    
    public static String join(Enumeration<String> e, String delim) {
        StringBuffer res = new StringBuffer();
        boolean first = true;
        while (e.hasMoreElements()) {
            if (first)
                first = false;
            else
                res.append(delim);
            res.append(e.nextElement());
        }
        return res.toString();
    }

    public static String join(String[] e, String delim) {
        StringBuffer res = new StringBuffer();
        boolean first = true;
        if (e == null || e.length == 0) {
            return res.toString();
        }
        for (int ii = 0; ii < e.length; ii++) {
            if (first)
                first = false;
            else
                res.append(delim);
            res.append(e[ii]);
        }
        return res.toString();
    }
    
    public static String join(String delimiter, String... tokens) {
        StringBuffer res = new StringBuffer();
        boolean first = true;
        if (tokens == null || tokens.length == 0) {
            return res.toString();
        }
        for (int ii = 0; ii < tokens.length; ii++) {
            if (first)
                first = false;
            else
                res.append(delimiter);
            res.append(tokens[ii]);
        }
        return res.toString();
    }

    public static String genRandomString(int len, String charset) {
        int cslen = charset.length();
        StringBuffer result = new StringBuffer();
        for (int ii = 0; ii < len; ii++) {
            result.append(charset.charAt((int) (cslen * Math.random())));
        }
        return result.toString();
    }
    
    public static String longToFormatDate(long dl, String format) {
		Date d = new Date(dl);
		SimpleDateFormat dFormat = new SimpleDateFormat(format);
		return dFormat.format(d);
    }
    
}
