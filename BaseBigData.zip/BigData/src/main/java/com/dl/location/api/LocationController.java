package com.dl.location.api;

import java.awt.geom.Area;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.RichTextString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dl.location.admin.data.Product;
import com.dl.location.admin.data.ProductLocation;
import com.dl.location.service.LocationService;
@Controller
@RequestMapping("/api/location")
public class LocationController {
	@Autowired
	private LocationService locationService;
	@ResponseBody
	@RequestMapping(value = "/productList", method = RequestMethod.GET)
	public ApiValue productList(){
		List<Product> list = locationService.getproduct();
		
		ApiValue apiValue = new ApiValue();
		apiValue.setErrCode(1);
		apiValue.setErrMsg("success");
		apiValue.setValue(list);
		
		return apiValue;
	}
	@ResponseBody
	@RequestMapping(value = "/brandList", method = RequestMethod.GET)
	public ApiValue brandList(@RequestParam("product")String product){
		//System.out.println("jump onto brandList");
		List<Product> list = locationService.getbrand(product);
		
		ApiValue apiValue = new ApiValue();
		apiValue.setErrCode(1);
		apiValue.setErrMsg("success");
		apiValue.setValue(list);
		
		return apiValue;
	}
	
	//getLocation
	@ResponseBody
	@RequestMapping(value = "/getLocation", method = RequestMethod.GET)
	public ApiValue getLocation(){
		//System.out.println("jump onto brandList");
		List<ProductLocation> list = locationService.getLocation();
		
		ApiValue apiValue = new ApiValue();
		apiValue.setErrCode(1);
		apiValue.setErrMsg("success");
		apiValue.setValue(list);
		
		return apiValue;
	}
	public static void main(String[] args) {
		
		LocationController controller=new  LocationController();
		
		
		//controller.getHeatPointCount();
		//List<Weight> list = locationService.getHeatPointCountPeopleList();
	}
 
	
}