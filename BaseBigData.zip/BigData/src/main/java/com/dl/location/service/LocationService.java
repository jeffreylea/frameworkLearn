package com.dl.location.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dl.location.admin.data.Product;
import com.dl.location.admin.data.ProductLocation;



public interface LocationService {
	public List<Product> getproduct();
	public List<ProductLocation> getLocation();
	public List<Product> getbrand(@Param("product") String product );
	}

