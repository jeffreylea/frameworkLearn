package com.dl.location.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dl.location.api.ApiValue;
import com.dl.location.facade.ExpenseAccountFacade;
import com.dl.location.util.CalendarUtil;
import com.dl.location.util.DataContextHolder;
import com.sun.javafx.sg.prism.NGShape.Mode;

@Controller
@RequestMapping("/page")
public class PageController {

	public static final Logger logger = LoggerFactory.getLogger(PageController.class);

	protected static final int PAGE_MAX_COUNT = 20;

	
	// ssssssssssssssssssssssssssss
		@RequestMapping(value = "/sum", method = RequestMethod.GET)
		public String sum(HttpServletRequest request, Model model) {
			return "/sum";
		}
		@RequestMapping(value = "/bigDataIndex", method = RequestMethod.GET)
		public String bigDataIndex(HttpServletRequest request, Model model) {
			return "/bigDataIndex";
		}

}
