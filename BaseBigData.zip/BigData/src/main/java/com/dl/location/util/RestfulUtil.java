package com.dl.location.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import net.sf.json.JSONObject;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

public class RestfulUtil {
	public static Object getRestfulResult(String url) {
		StringBuffer sb = new StringBuffer();
		Object obj = null;
		try {
			System.out.println("url:"+url);
			URL restServiceURL = new URL(url);
			HttpURLConnection httpConnection = (HttpURLConnection) restServiceURL
					.openConnection();
			httpConnection.setRequestMethod("GET");
			httpConnection.setRequestProperty("Accept", "application/json");
			httpConnection.setRequestProperty("Accept-Charset", "utf-8");
			httpConnection.setRequestProperty("contentType", "utf-8");
			
			if (httpConnection.getResponseCode() != 200) {
				throw new RuntimeException(
						"HTTP GET Request Failed with Error code : "
								+ httpConnection.getResponseCode());
			}

			BufferedReader responseBuffer = new BufferedReader(
					new InputStreamReader(httpConnection.getInputStream(),
							"utf-8"));

			String output = "";
			output = URLEncoder.encode(output, "utf-8");
			
			while ((output = responseBuffer.readLine()) != null) {
				sb.append(output);
			}

			httpConnection.disconnect();
			System.out.println("result:"+sb.toString());
			obj = new String(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	public static Object getPostRestfulResult(String url,
			Map<String, String> data) {
		StringBuffer sb = new StringBuffer();
		Object obj = null;
		try {

			URL restServiceURL = new URL(url);
			HttpURLConnection httpConnection = (HttpURLConnection) restServiceURL
					.openConnection();
			// 设置http连接属性
			httpConnection.setDoOutput(true);
			httpConnection.setDoInput(true);
			httpConnection.setRequestMethod("POST");
			// 可以根据需要 提交
			// GET、POST、DELETE、INPUT等http提供的功能
			httpConnection.setUseCaches(false);// 设置缓存
			httpConnection.setInstanceFollowRedirects(true);
			httpConnection.setRequestProperty("accept", "*/*");
			httpConnection.setRequestProperty("connection", "Keep-Alive");
			// 设置http头 消息
			// httpConnection.setRequestProperty("Content-Type","application/json");
			// // 设定 请求格式 json，也可以设定xml格式的
			httpConnection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			// connection.setRequestProperty("Content-Type", "text/xml"); //设定
			// 请求格式 xml，
			// httpConnection.setRequestProperty("Accept",
			// "application/json");// 设定响应的信息的格式为
			httpConnection.setRequestProperty("Content-Type", "text/xml"); // json，也可以设定xml格式的
			httpConnection.setRequestProperty("Charset", "utf-8");
			// //特定http服务器需要的信息，根据服务器所需要求添加
			httpConnection.connect();
			JSONObject jdata = new JSONObject();
			for (String Key : data.keySet()) {
				jdata.element(Key, data.get(Key));
			}
			DataOutputStream out = new DataOutputStream(
					httpConnection.getOutputStream());
			// System.out.println("out"+httpConnection.getOutputStream());
			out.writeBytes(jdata.toString());
			out.flush();
			out.close();

			// 读取响应
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					httpConnection.getInputStream(), "utf-8"));
			String lines;
			while ((lines = reader.readLine()) != null) {
				lines = new String(lines.getBytes());
				sb.append(lines);
			}

			reader.close();
			httpConnection.disconnect();
			obj = JSON.parse(sb.toString().getBytes("utf8"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}

	public static String sendMessage(String url, String postData) {
		String res = "";
		try {
			URL serverUrl = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) serverUrl
					.openConnection();
			conn.setConnectTimeout(20000);
			conn.setRequestMethod("POST");
			conn.addRequestProperty("Referer", url);
			conn.addRequestProperty("Accept", "*/*");
			conn.addRequestProperty("Accept-Language", "zh-cn");
			conn.addRequestProperty("Content-type",
					"application/x-www-form-urlencoded");
			conn.addRequestProperty(
					"User-Agent",
					"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727)");
			// conn.addRequestProperty("Cookie",
			// "JSESSIONID=60769A616C7132CB8BD8023AC05D214D;");
			conn.setDoOutput(true);
			conn.connect();
			conn.getOutputStream().write(postData.getBytes());
			InputStream ins = conn.getInputStream();
			String charset = "UTF-8";
			InputStreamReader inr = new InputStreamReader(ins, charset);
			BufferedReader br = new BufferedReader(inr);
			String line = "";
			StringBuffer sb = new StringBuffer();
			do {
				sb.append(line);
				line = br.readLine();
			} while (line != null);
			res = sb.toString();
		} catch (Throwable e) {
			e.printStackTrace();
			res = e.toString();
		}
		return res;
	}

	public static Object postRestfulResult(String url,
			Map<String, String> data, String paramType) {
		StringBuffer sb = new StringBuffer();
		Object obj = null;
		try {
			
			URL restServiceURL = new URL(url);
			HttpURLConnection httpConnection = (HttpURLConnection) restServiceURL
					.openConnection();
			// 设置http连接属性
			httpConnection.setDoOutput(true);
			httpConnection.setDoInput(true);
			httpConnection.setRequestMethod("POST");
			// 可以根据需要 提交
			// GET、POST、DELETE、INPUT等http提供的功能
			httpConnection.setUseCaches(false);// 设置缓存
			httpConnection.setInstanceFollowRedirects(true);
			httpConnection.setRequestProperty("accept", "*/*");
			httpConnection.addRequestProperty("Accept-Language", "zh-cn");
			httpConnection.setRequestProperty("connection", "Keep-Alive");
			// 设置http头 消息
			if (paramType.equals("json")) {
				httpConnection.setRequestProperty("Content-Type",
						"application/json");
			} else if (paramType.equals("form")) {
				// // 设定 请求格式 json，也可以设定xml格式的
				httpConnection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
			} else if (paramType.equals("xml")) {
				httpConnection.setRequestProperty("Content-Type", "text/xml");
			}
			httpConnection.setRequestProperty("Charset", "utf-8");
			// //特定http服务器需要的信息，根据服务器所需要求添加
			httpConnection.connect();
			DataOutputStream out = new DataOutputStream(
					httpConnection.getOutputStream());

			if (paramType.equals("json")) {
				JSONObject jdata = new JSONObject();
				for (String Key : data.keySet()) {
					jdata.element(Key, data.get(Key));
				}
				// System.out.println("out"+httpConnection.getOutputStream());
				out.write(jdata.toString().getBytes("utf-8"));
			} else if (paramType.equals("form")) {
				String param = "";
				int count = 0;
				for (String Key : data.keySet()) {
					count++;
					if (count == data.size()) {
						param += (Key + "=" + data.get(Key));
					} else {
						param += (Key + "=" + data.get(Key) + "&");
					}
				}
				System.out.println("param:" + param);
				out.write(param.getBytes("utf-8"));

			} else if (paramType.equals("xml")) {
				String param = data.get("xml");
				System.out.println("param:" + param);
				out.write(param.getBytes("utf-8"));
			}
			out.flush();
			out.close();

			BufferedReader reader = null;

			if (httpConnection.getResponseCode() == 500) {
				// 读取响应
				reader = new BufferedReader(new InputStreamReader(
						httpConnection.getErrorStream(), "utf-8"));
			} else {
				// 读取响应
				reader = new BufferedReader(new InputStreamReader(
						httpConnection.getInputStream(), "utf-8"));
			}
			String lines;
			while ((lines = reader.readLine()) != null) {
				lines = new String(lines.getBytes());
				sb.append(lines);
			}

			reader.close();
			httpConnection.disconnect();
			if (paramType.equals("xml")) {
				return new String(sb.toString().getBytes("utf-8"));
			} else {
				obj = JSON.parse(sb.toString().getBytes("utf-8"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return obj;
	}
	
	public static String beidouPostRestfulResult(String url,
			Map<String, String> data, String paramType) {
		StringBuffer sb = new StringBuffer();
		String ret = "";
		try {

			URL restServiceURL = new URL(url);
			HttpURLConnection httpConnection = (HttpURLConnection) restServiceURL
					.openConnection();
			// 设置http连接属性
			httpConnection.setDoOutput(true);
			httpConnection.setDoInput(true);
			httpConnection.setRequestMethod("POST");
			// 可以根据需要 提交
			// GET、POST、DELETE、INPUT等http提供的功能
			httpConnection.setUseCaches(false);// 设置缓存
			httpConnection.setInstanceFollowRedirects(true);
			httpConnection.setRequestProperty("accept", "*/*");
			httpConnection.addRequestProperty("Accept-Language", "zh-cn");
			httpConnection.setRequestProperty("connection", "Keep-Alive");
			// 设置http头 消息
			if (paramType.equals("json")) {
				httpConnection.setRequestProperty("Content-Type",
						"application/json");
			} else if (paramType.equals("form")) {
				// // 设定 请求格式 json，也可以设定xml格式的
				httpConnection.setRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
			} else if (paramType.equals("xml")) {
				httpConnection.setRequestProperty("Content-Type", "text/xml");
			}
			httpConnection.setRequestProperty("Charset", "utf-8");
			// //特定http服务器需要的信息，根据服务器所需要求添加
			httpConnection.connect();
			DataOutputStream out = new DataOutputStream(
					httpConnection.getOutputStream());

			if (paramType.equals("json")) {
				JSONObject jdata = new JSONObject();
				for (String Key : data.keySet()) {
					jdata.element(Key, data.get(Key));
				}
				// System.out.println("out"+httpConnection.getOutputStream());
				out.write(jdata.toString().getBytes("utf-8"));
			} else if (paramType.equals("form")) {
				String param = "";
				int count = 0;
				for (String Key : data.keySet()) {
					count++;
					if (count == data.size()) {
						param += (Key + "=" + data.get(Key));
					} else {
						param += (Key + "=" + data.get(Key) + "&");
					}
				}
				System.out.println("param:" + param);
				out.write(param.getBytes("utf-8"));

			} else if (paramType.equals("xml")) {
				String param = data.get("xml");
				System.out.println("param:" + param);
				out.write(param.getBytes("utf-8"));
			}
			out.flush();
			out.close();

			BufferedReader reader = null;

			if (httpConnection.getResponseCode() == 500) {
				// 读取响应
				reader = new BufferedReader(new InputStreamReader(
						httpConnection.getErrorStream(), "utf-8"));
			} else {
				// 读取响应
				reader = new BufferedReader(new InputStreamReader(
						httpConnection.getInputStream(), "utf-8"));
			}
			String lines;
			while ((lines = reader.readLine()) != null) {
				lines = new String(lines.getBytes());
				sb.append(lines);
			}

			reader.close();
			httpConnection.disconnect();
			return new String(sb.toString().getBytes());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	
	public static void debugGPS() {
		try {
			Map<String, String> data = new HashMap<String, String>();
			// version=1&method=vLoginSystem&name=鲁BF7892&pwd=000000
			data.put("version", 1 + "");
			data.put("method", "vLoginSystem");
			data.put("name", "鲁BS8579");
			data.put("pwd", "000000");

			com.alibaba.fastjson.JSONObject json = (com.alibaba.fastjson.JSONObject) postRestfulResult(
					"http://119.167.225.119:89/gpsonline/GPSAPI", data, "form");
			if (json != null) {
				System.out.println(json.toString());

				System.out.println("vid:" + json.getString("vid") + "; vKey:"
						+ json.getString("vKey"));

				// version=1&method=loadHistory&vid=4103747&vKey=2e8b868d779f1e1c0696e04113e79003&bTime=1375459200000&eTime=1375545599000

				Map<String, String> data1 = new HashMap<String, String>();
				data1.put("version", "1");
				data1.put("method", "loadHistory");
				data1.put("vid", json.getString("vid"));
				data1.put("vKey", json.getString("vKey"));

				Calendar c = Calendar.getInstance();

				String startTime = "2016-07-24 00:00:00";
				String endTime = "2016-07-24 23:00:00";
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");

				c.setTime(df.parse(startTime));
				long startTimeMillis = c.getTimeInMillis();

				c.setTime(df.parse(endTime));
				long endTimeMIllis = c.getTimeInMillis();

				data1.put("bTime", String.valueOf(startTimeMillis));
				data1.put("eTime", String.valueOf(endTimeMIllis));

				com.alibaba.fastjson.JSONObject json1 = (com.alibaba.fastjson.JSONObject) postRestfulResult(
						"http://119.167.225.119:89/gpsonline/GPSAPI", data1,
						"form");
				if (json1 != null) {
					System.out.println(json1.toString());

					boolean success = json1.getBooleanValue("success");
					if (success) {
						JSONArray history = json1.getJSONArray("history");
						if (history != null && history.size() > 0) {
							for (int i = 0; i < history.size(); i++) {
								com.alibaba.fastjson.JSONObject hData = history
										.getJSONObject(i);
								System.out.println("*****hData" + i
										+ " begin*****");
								System.out.println("id:"
										+ hData.getLongValue("id"));
								System.out.println("gpst:"
										+ hData.getString("gpst"));
								System.out.println("lat:"
										+ hData.getFloatValue("lat"));
								System.out.println("lng:"
										+ hData.getFloatValue("lng"));
								System.out.println("posinfo:"
										+ hData.getString("posinfo"));
								System.out.println("totalDistance:"
										+ hData.getFloatValue("totaldistance"));
								System.out.println("dis:"
										+ hData.getFloatValue("dis"));
								System.out.println("oil:"
										+ hData.getFloatValue("oil"));
								System.out.println("state:"
										+ hData.getString("state"));
								System.out.println("*****hData" + i
										+ " end*****");
							}
						}
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		//debugBeiDou();
		debugGPS();
	}

}
