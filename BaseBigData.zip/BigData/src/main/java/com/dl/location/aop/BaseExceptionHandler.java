package com.dl.location.aop;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class BaseExceptionHandler {

//	@ExceptionHandler(RuntimeException.class)
//	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
//	@ResponseBody
//	public String handleInvalidRequestError(RuntimeException ex) {
//		System.out.println("handleInvalidRequestError erro:"+ex.getMessage());
//		return HttpStatus.BAD_REQUEST+"";
//	}

	@ExceptionHandler(RuntimeException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public String handleUnexpectedServerError(RuntimeException ex) {
		System.out.println("handleUnexpectedServerError erro:"+ex.getMessage());
		return HttpStatus.INTERNAL_SERVER_ERROR+":"+ex.getMessage();
	}
}
