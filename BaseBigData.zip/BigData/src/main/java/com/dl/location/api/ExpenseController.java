package com.dl.location.api;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dl.location.util.CalendarUtil;
import com.dl.location.util.DataContextHolder;
import com.dl.location.util.DateUtil;
import com.dl.location.util.ErrorCode;
import com.dl.location.util.SmsUtil;
import com.google.gson.Gson;

@Controller
@RequestMapping("/api/expense")
public class ExpenseController {


	@InitBinder
	public void initBinder(WebDataBinder binder) {
	}

	protected static final Logger logger = LoggerFactory
			.getLogger(ExpenseController.class);

	private static final int PAGE_MAX_COUNT = 1000;


	public static void main(String[] args) {
		String startTime = "2016-06-28 13:45:00";
		System.out.println(startTime.substring(0, 10) + " 00:00:00");
	}

}
