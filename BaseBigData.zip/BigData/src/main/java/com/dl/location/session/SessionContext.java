package com.dl.location.session;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class SessionContext {
	
	private CacheManager cacheManager;
	
	public void setCacheManager(CacheManager cacheManager) {
		this.cacheManager = cacheManager;
	}

	public SessionMap getSession(String sessionId, boolean newIfAbsent) {
		Cache sessionCache = cacheManager.getCache("sessionCache");
		Element element = sessionCache.get(sessionId);
		if (element != null) {
			Object value = element.getObjectValue();
			if (value != null && value instanceof SessionMap) {
				return (SessionMap)value;
			}
		}
		if (newIfAbsent) {
			SessionMap session = new SessionMap();
			Element newElement = new Element(sessionId, session);
			sessionCache.put(newElement);
			return session;
		}
		return null;
	}
	
	public void invalidateSession(String sessionId) {
		Cache sessionCache = cacheManager.getCache("sessionCache");
		sessionCache.remove(sessionId);
	}
	
}
