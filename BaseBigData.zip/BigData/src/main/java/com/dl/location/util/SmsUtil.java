package com.dl.location.util;

import java.util.HashMap;
import java.util.Map;

public class SmsUtil {
	public static void sendOutMessage(String mobile, String content){
		//String url = "http://dx.qxtsms.cn/sms.aspx?action=send&userid=2447&account=sfwl&password=15563962933&mobile="+mobile+"&content="+content+"&sendTime=&checkcontent=0";
		//RestfulUtil.getRestfulResult(url);
		
		String url = "http://dx.qxtsms.cn/sms.aspx";
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("action", "send");
		data.put("userid", "2447");
		data.put("account", "sfwl");
		data.put("password", "15563962933");
		data.put("mobile", mobile);
		data.put("content", content);
		data.put("sendTime", "");
		data.put("checkcontent", "0");
		
		RestfulUtil.postRestfulResult(url, data, "form");
	}
	
	public static void main(String[] arg0){
		sendOutMessage("13646480021", "您的报销单已提交");
	}
	
}
