package com.dl.location.util;

public class ErrorCode {

	public static final String CommonError_NeedLogIn = "会话已过期，请重新登录";
	public static final String CommonError_FunctionNotSupported = "系统不支持该功能";
	
	public static final String CommonError_NoDataFound = "没有找到相应数据";
	public static final String CommonError_LogonErrorEmpty = "无法登陆，用户名或密码为空";
	public static final String CommonError_LogonErrorMismatch = "无法登陆，用户名或密码错误";
	
	public static final String CommonInfo_NoApprovalNeeded = "系统自动填写：不需要审核";
	public static final String CommonInfo_ApprovalComplete = "系统自动填写：审核通过";
	public static final String CommonInfo_GeneratedStockOut = "系统自动填写：自动创建的出库单";
	public static final String CommonInfo_Approving = "审批通过";
	public static final String CommonInfo_Approved = "审批生效";
	
	public static final String OrderInfo_ApprovedOrderCanNotBeModified = "订单已经审批通过，不允许修改，只能撤销";
	public static final String OrderInfo_OrderWithLoadedStockOutCanNotBeDeleted = "出库单已经出库，无法删除或撤销订单";
	public static final String OrderInfo_LoadedStockOutCanNotBeDeleted = "出库单已经出库，无法修改、删除或撤销";
	
	public static final String OrderInfo_CustomerArrearage = "无法创建订单，客户油费或运费已欠费";
	public static final String CommonError_CustomerTaxNeeded = "添加客户错误：税号必须填写";
	public static final String CommonError_CustomerTaxExisted = "添加客户错误：拥有该税号的用户已经存在";
	
	public static final String OrderInfo_DataError_ProductMismatch = "无法出库：出库油罐油品类型同订单油品类型不相同";
	public static final String OrderInfo_TooLongTime = "无法删除：入库单入库时间已超过时间限制";
	
	
	
	public static final int ERROR_CODE_LOGIN_SUCCESS = 10000;
	public static final String ERROR_MSG_LOGIN_SUCCESS = "登录成功!";
	public static final int ERROR_CODE_LOGIN_PWD_WRONG = 10001;
	public static final String ERROR_MSG_LOGIN_PWD_WRONG = "密码错误!";
	public static final int ERROR_CODE_LOGIN_USER_NOT_FOUND = 10002;
	public static final String ERROR_MSG_LOGIN_USER_NOT_FOUND = "未找到相关用户!";
	
	public static final int ERROR_CODE_LIST_EXPENSE_SUCCESS = 20000;
	public static final String ERROR_MSG_LIST_EXPENSE_SUCCESS = "获取报销单列表成功!";
	
	public static final int ERROR_CODE_EXPENSE_DETAIL_SUCCESS = 30000;
	public static final String ERROR_MSG_EXPENSE_DETAIL_SUCCESS = "获取报销单详情成功!";
	
	public static final int ERROR_CODE_USER_ROLE_SUCCESS = 40000;
	public static final String ERROR_MSG_USER_ROLE_SUCCESS = "获取人员成功!";
	
	public static final int ERROR_CODE_COMMIT_SUCCESS = 50000;
	public static final String ERROR_MSG_COMMIT_SUCCESS = "提交成功!";
	
	public static final int ERROR_CODE_AUDIT_SUCCESS = 60000;
	public static final String ERROR_MSG_AUDIT_SUCCESS = "审核操作成功!";
}
