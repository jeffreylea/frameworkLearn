package com.dl.location.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.dl.location.api.ApiValue;

public interface ExpenseAccountService {
	/*
	public VeExpenseAccount addExpenseAccount(VeExpenseAccount expenseAccount);

	public VeExpenseAccount updateExpenseAccount(VeExpenseAccount expenseAccount);

	public VeExpenseAccount getExpenseAccount(int id);

	public List<VeExpenseAccount> getExpenseAccountList(@Param("userId") String userId, @Param("role") VeUserRoleEnum role, @Param("page") int page);
	public int getExpenseAccountListCount(@Param("userId") String userId, @Param("role") VeUserRoleEnum role);
	
	public List<VeExpenseAccount> getExpenseAccountListByStatus(VeExpenseStatusEnum status, @Param("userId") String userId, @Param("role") VeUserRoleEnum role, @Param("page") int page);
	public int getExpenseAccountListCountByStatus(VeExpenseStatusEnum status, @Param("userId") String userId, @Param("role") VeUserRoleEnum role);
	
	public List<VeExpenseAccount> getExpenseAccountListByVehicleNum(@Param("vehicleNum") String vehicleNum);
	
	public List<VeExpenseAccount> getExpenseAccountListByCreateDate(
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate, @Param("userId") String userId, @Param("role") VeUserRoleEnum role, @Param("page") int page);
	public int getExpenseAccountListCountByCreateDate(
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate, @Param("userId") String userId, @Param("role") VeUserRoleEnum role);
	
	public List<VeExpenseAccount> getExpenseAccountListByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate,
			@Param("userId") String userId,
			@Param("role") VeUserRoleEnum role,
			@Param("page") int page);
	
	public int getExpenseAccountListCountByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate,
			@Param("userId") String userId,
			@Param("role") VeUserRoleEnum role);
	
	public List<VeExpenseVo> getExpenseVoList(String userId, int role, 
			int status, String startDate, String endDate, String employeeId, int page);
	
	public Map<String, Object> getExpenseAccountDetail(int id);
	public void commit(String userId, String auditorId, int expenseId);
	public void commitAll(String userId, String auditorId, String expenseIds);
	
	public void audit(String fromAuditorId, String toAuditorId, int expenseId,
			int type, int role, String comment);
	
	public void auditAll(String fromAuditorId, String toAuditorId,
			int type, int role, String comment, String expenseIds);
	
	public String getLatestSn(String currentDay);
	public double getSumAmountBySubmitter(String userId, VeUserRoleEnum role, VeExpenseStatusEnum status);
	public double getSumAmountByAuditor(String auditorId, VeUserRoleEnum role, VeExpenseStatusEnum status);
	
	public double getSumAmountBySubmitter(ExpenseSearchVo expenseSearchVo);
	public double getSumAmountByAuditor(ExpenseSearchVo expenseSearchVo);
	
	
	public double getSumAmountAll(VeExpenseStatusEnum status);
	public double getSumAmountAll(ExpenseSearchVo expenseSearchVo);
	
	
	public List<VeExpenseAccount> filterExpenseAccount(ExpenseSearchVo expenseSearchVo);
	public int countExpenseAccount(ExpenseSearchVo expenseSearchVo);
	*/
}
