package com.dl.location.session;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dl.location.util.ErrorCode;
import com.dl.location.util.StringUtil;

public class SessionManagerFilter implements Filter {
	private SessionContext sessionContext;
	private List<String> excludedUrls = new ArrayList<String>();

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		
			for (String url : excludedUrls) {
				if (httpRequest.getRequestURI().contains(url.trim())) {
					chain.doFilter(request, response);
					return;
				}
			}
		
		String token = httpRequest.getHeader("token");
		SessionMap session = sessionContext.getSession(token, false);
		if (session == null) {			
			Cookie[] cookies = httpRequest.getCookies();
			if (cookies != null) {
				for (Cookie cookie:cookies) {
					if ("token".equals(cookie.getName())) {
						session = sessionContext.getSession(token, false);
						break;
					}
				}
			}
		}
		
		if (session != null) {			
			chain.doFilter(request, response);
		} else {
			PrintWriter writer = response.getWriter();
			writer.write(ErrorCode.CommonError_NeedLogIn);
			writer.flush();
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(config.getServletContext());
		sessionContext = context.getBean(SessionContext.class);
		
		String excludedUrlsValue = config.getInitParameter("excludedUrls");
		if (!StringUtils.isEmpty(excludedUrlsValue)) {
			excludedUrls = StringUtil.splitToList(excludedUrlsValue, ",");
		}
	}

}
