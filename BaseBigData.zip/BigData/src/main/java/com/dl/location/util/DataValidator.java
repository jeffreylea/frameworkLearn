package com.dl.location.util;

import java.security.InvalidParameterException;

public class DataValidator {

    public static boolean isEqual(byte[] bytes1, byte[] bytes2) {
        if (bytes1 == null)
            return bytes2 != null;
        if (bytes2 == null)
            return bytes1 != null;
        if (bytes1.length != bytes2.length)
            return false;
        for (int i = 0; i < bytes1.length; i++) {
            if (bytes1[i] != bytes2[i])
                return false;
        }
        return true;
    }
    
    public static int getLength(byte[] bytes) {
        if (isEmpty(bytes))
            return 0;
        return bytes.length;
    }

    public static boolean isNull(Object obj) {
        return (obj == null);
    }

    public static boolean isAnyoneNull(Object... objs) {
        if (objs == null || objs.length == 0)
            return true;
        for (Object obj : objs)
            if (isNull(obj))
                return true;
        return false;
    }

    public static void ensureNotEmpty(byte[] bytes) {
        if (isEmpty(bytes))
            throw new InvalidParameterException();
    }

    public static void ensureNotNull(Object... objs) {
        if (objs == null || objs.length == 0)
            throw new InvalidParameterException();
        for (Object obj : objs)
            ensureNotNull(obj);
    }

	public static void ensureNotNull(Object obj) {
		if (obj == null)
			throw new InvalidParameterException();
	} 

	public static void ensureNotNull(String obj) {
		if (obj == null || obj.length() == 0)
			throw new InvalidParameterException();
	}
	
	public static void ensureNotNull(String... objs) {
		if (objs == null || objs.length == 0)
			throw new InvalidParameterException();
		for (String obj : objs)
			ensureNotNull(obj);
	}
	
	public static void ensureNotNegative(int obj) {
        if (obj < 0)
            throw new InvalidParameterException();
    }

    public static boolean isEmpty(byte[] bytes) {
        return (bytes == null || bytes.length == 0);
    }
}
