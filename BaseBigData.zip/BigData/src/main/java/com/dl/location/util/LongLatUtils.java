package com.dl.location.util;

public class LongLatUtils {
	public static final int PixelsPerTile = 256;
	public static final double MinLatitude  = -85.0511287798;
	public static final double  MaxLatitude = 85.0511287798;
	public static final double  MinLongitude = -180;
	public static final double  MaxLongitude = 180;
	public static final double  EarthRadiusInMeters =  6378137;
	public static final double  EarthCircumferenceMeters = 40075016.6855785724052;
	
	public static double[] longLatToMeters(double longitude, double latitude)
    {
        double originShift = EarthCircumferenceMeters / 2.0;
		latitude = clip(latitude, MinLatitude, MaxLatitude);
		longitude = clip(longitude, MinLongitude, MaxLongitude);
		double x = longitude * originShift / 180.0;
		double y= Math.log(Math.tan((90 + latitude) * Math.PI / 360.0 )) / (Math.PI / 180.0);

		y = y * originShift / 180.0;
		
		double[] xy = new double[2];
		
		xy[0] = x;
		xy[1] = y;
		
		return xy;
		
		/*x=longitude;
		y=latitude;*/
	}
	
	public static double[] meterToLongLat(double x, double y)
    {
		double originShift = EarthCircumferenceMeters / 2.0;
		double longitude = x / originShift * 180;
		double latitude = y / originShift * 180;
		latitude = 180 / Math.PI * (2 * Math.atan(Math.exp(latitude * Math.PI / 180)) - Math.PI / 2);
		
		double[] longLat = new double[2];
		longLat[0] = longitude;
		longLat[1] = latitude;
		
		return longLat;

	}
	
	public static double clip(double value, double minValue, double maxValue)
    {
		return Math.min(Math.max(value, minValue), maxValue);
	}
	
	public static double getDistance(double x1,double y1,double x2,double y2){
		double d = (x2-x1)*(x2-x1) - (y2-y1)*(y2-y1);
		return Math.sqrt(d);
	}
	
	public static double getDistanceLatLong(double x, double y, double x1, double y1) {

		double lon1 = (Math.PI / 180) * x;
		double lon2 = (Math.PI / 180) * x1;
		double lat1 = (Math.PI / 180) * y;
		double lat2 = (Math.PI / 180) * y1;

		// double Lat1r = (Math.PI/180)*(gp1.getLatitudeE6()/1E6);
		// double Lat2r = (Math.PI/180)*(gp2.getLatitudeE6()/1E6);
		// double Lon1r = (Math.PI/180)*(gp1.getLongitudeE6()/1E6);
		// double Lon2r = (Math.PI/180)*(gp2.getLongitudeE6()/1E6);

		// 地球半径
		double R = 6371;

		// 两点间距离 km，如果想要米的话，结果*1000就可以了
		double d = Math.acos(Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1)
				* Math.cos(lat2) * Math.cos(lon2 - lon1))
				* R;

		return d * 1000;
	}
}
