package com.dl.location.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dl.location.dao.ExpenseAccountDao;
import com.dl.location.service.ExpenseAccountService;
import com.dl.location.util.SmsUtil;

@Service
public class ExpenseAccountServiceImpl implements ExpenseAccountService {
	
	/*
	 
	@Resource
	private ExpenseAccountDao expenseAccountDao;
	@Resource
	private ExpenseItemDao expenseItemDao;
	@Resource
	private MaterialOrderDao materialOrderDao;
	@Resource
	private UserProfileDao userDao;
	@Resource
	private ExpenseAuditorService expenseAuditorService;

	protected static final Logger logger = LoggerFactory
			.getLogger(ExpenseAccountService.class);

	protected static final int PAGE_MAX_COUNT = 20;

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public VeExpenseAccount addExpenseAccount(VeExpenseAccount expenseAccount) {
		expenseAccountDao.addExpenseAccount(expenseAccount);
		int id = expenseAccountDao.getAutoId();
		expenseAccount.setId(id);
		return expenseAccount;
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public VeExpenseAccount updateExpenseAccount(VeExpenseAccount expenseAccount) {
		System.out.println("businessDays:" + expenseAccount.getBusinessDays());
		expenseAccountDao.updateExpenseAccount(expenseAccount);
		return expenseAccount;

	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> getExpenseAccountList(
			@Param("userId") String userId, @Param("role") VeUserRoleEnum role,
			@Param("page") int page) {
		if (role == VeUserRoleEnum.FINANCE) {
			return expenseAccountDao.getExpenseAccountListAll((page - 1)
					* PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		} else {
			return expenseAccountDao.getExpenseAccountList(userId, role,
					(page - 1) * PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		}
	}

	@Override
	public int getExpenseAccountListCount(@Param("userId") String userId,
			@Param("role") VeUserRoleEnum role) {
		int totalCount = 0;
		if (role == VeUserRoleEnum.FINANCE) {
			totalCount = expenseAccountDao.getExpenseAccountListCountAll();
		} else {
			totalCount = expenseAccountDao.getExpenseAccountListCount(userId,
					role);
		}
		logger.info("totalCount:" + totalCount);
		return (totalCount % PAGE_MAX_COUNT) > 0 ? (totalCount / PAGE_MAX_COUNT + 1)
				: totalCount / PAGE_MAX_COUNT;
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> getExpenseAccountListByStatus(
			VeExpenseStatusEnum status, String userId,
			@Param("role") VeUserRoleEnum role, int page) {
		if (role == VeUserRoleEnum.FINANCE) {
			return expenseAccountDao.getExpenseAccountListByStatusAll(status,
					(page - 1) * PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		} else {
			return expenseAccountDao.getExpenseAccountListByStatus(status,
					userId, role, (page - 1) * PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		}
	}

	@Override
	public int getExpenseAccountListCountByStatus(VeExpenseStatusEnum status,
			String userId, @Param("role") VeUserRoleEnum role) {
		int totalCount = 0;
		if (role == VeUserRoleEnum.FINANCE) {
			totalCount = expenseAccountDao
					.getExpenseAccountListCountByStatusAll(status);
		} else {
			totalCount = expenseAccountDao.getExpenseAccountListCountByStatus(
					status, userId, role);
		}
		logger.info("totalCount:" + totalCount);
		return (totalCount % PAGE_MAX_COUNT) > 0 ? (totalCount / PAGE_MAX_COUNT + 1)
				: totalCount / PAGE_MAX_COUNT;
	}

	@Override
	public VeExpenseAccount getExpenseAccount(int id) {
		VeExpenseAccount expenseAccount = expenseAccountDao
				.getExpenseAccount(id);
		return expenseAccount;
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> getExpenseAccountListByVehicleNum(
			@Param("vehicleNum") String vehicleNum) {
		List<VeExpenseAccount> list = expenseAccountDao
				.getExpenseAccountListByVehicleNum(vehicleNum);
		return list;
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> getExpenseAccountListByCreateDate(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role, @Param("page") int page) {
		if (role == VeUserRoleEnum.FINANCE) {
			return expenseAccountDao.getExpenseAccountListByCreateDateAll(
					beginDate, endDate, (page - 1) * PAGE_MAX_COUNT,
					PAGE_MAX_COUNT);
		} else {
			return expenseAccountDao.getExpenseAccountListByCreateDate(
					beginDate, endDate, userId, role, (page - 1)
							* PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		}
	}

	@Override
	public int getExpenseAccountListCountByCreateDate(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role) {
		int totalCount = 0;
		if (role == VeUserRoleEnum.FINANCE) {
			totalCount = expenseAccountDao
					.getExpenseAccountListCountByCreateDateAll(beginDate,
							endDate);
		} else {
			totalCount = expenseAccountDao
					.getExpenseAccountListCountByCreateDate(beginDate, endDate,
							userId, role);
		}
		logger.info("totalCount:" + totalCount);
		return (totalCount % PAGE_MAX_COUNT) > 0 ? (totalCount / PAGE_MAX_COUNT + 1)
				: totalCount / PAGE_MAX_COUNT;
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> getExpenseAccountListByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role, @Param("page") int page) {
		if (role == VeUserRoleEnum.FINANCE) {
			return expenseAccountDao
					.getExpenseAccountListByStatusAndCreateDateAll(status,
							beginDate, endDate, (page - 1) * PAGE_MAX_COUNT,
							PAGE_MAX_COUNT);
		} else {
			return expenseAccountDao
					.getExpenseAccountListByStatusAndCreateDate(status,
							beginDate, endDate, userId, role, (page - 1)
									* PAGE_MAX_COUNT, PAGE_MAX_COUNT);
		}
	}

	@Override
	public int getExpenseAccountListCountByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("fromDate") String beginDate,
			@Param("toDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role) {
		int totalCount = 0;
		if (role == VeUserRoleEnum.FINANCE) {
			totalCount = expenseAccountDao
					.getExpenseAccountListCountByStatusAndCreateDateAll(status,
							beginDate, endDate);
		} else {
			totalCount = expenseAccountDao
					.getExpenseAccountListCountByStatusAndCreateDate(status,
							beginDate, endDate, userId, role);
		}
		logger.info("totalCount:" + totalCount);
		return (totalCount % PAGE_MAX_COUNT) > 0 ? (totalCount / PAGE_MAX_COUNT + 1)
				: totalCount / PAGE_MAX_COUNT;
	}

	@Override
	public List<VeExpenseVo> getExpenseVoList(String userId, int role,
			int status, String startDate, String endDate, String employeeId,
			int page) {
		VeExpenseStatusEnum statusEnum = StatusEnumUtil.convertToEnum(status);
		VeUserRoleEnum roleEnum = RoleEnumUtil.convertToEnum(role);
		logger.info("ExpenseAccountServiceImpl.getExpenseVoList -- userId:"
				+ userId + "; statusEnum:" + statusEnum + "; roleEnum:"
				+ roleEnum);

		ExpenseSearchVo expenseSearchVo = new ExpenseSearchVo();
		expenseSearchVo
				.setBeginDate(startDate != null && startDate.equals("") ? null
						: startDate);
		expenseSearchVo.setEndDate(endDate != null && endDate.equals("") ? null
				: endDate);
		expenseSearchVo.setUserId(userId);
		expenseSearchVo.setRole(roleEnum);
		expenseSearchVo.setStatus(statusEnum);
		expenseSearchVo.setEmployeeId(employeeId != null
				&& employeeId.equals("") ? null : employeeId);
		expenseSearchVo.setStart((page - 1) * PAGE_MAX_COUNT);
		expenseSearchVo.setCount(PAGE_MAX_COUNT);

		switch (roleEnum) {
		case DISPATCHER:
			return expenseAccountDao
					.getExpenseVoListBySubmitId(expenseSearchVo);
		case DEPART_LEADER:
		case PROJECT_LEADER:
		case MANAGER:
			switch (statusEnum) {
			case AUDITED:
			case AUDIT_FAILED:
				return expenseAccountDao
						.getExpenseVoListByStatus(expenseSearchVo);
			case AUDITING:
				return expenseAccountDao
						.getExpenseVoListByStatusAuditing(expenseSearchVo);
			case WAIT_AUDIT:
				return expenseAccountDao
						.getExpenseVoListByStatusWaitAudit(expenseSearchVo);
			default:
				return new ArrayList<VeExpenseVo>();
			}
		default:
			return new ArrayList<VeExpenseVo>();
		}
	}

	@Override
	public Map<String, Object> getExpenseAccountDetail(int id) {
		VeExpenseAccount expenseAccount = expenseAccountDao
				.getExpenseAccount(id);
		// List<VeExpenseItem> itemList = expenseItemDao
		// .getExpenseItemListByExpenseAccountId(id);
		// List<VeMaterialOrder> materialOrderList = materialOrderDao
		// .getMaterialOrderByExpenseId(id);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("expenseAccount", expenseAccount);
		map.put("expenseItems", null);
		map.put("materialOrder", null);

		return map;
	}

	@Override
	public void commit(String userId, String auditorId, int expenseId) {
		expenseAccountDao.commit(auditorId, expenseId);
		// 更新expense auditor表
		VeExpenseAuditor expenseAuditor = new VeExpenseAuditor();
		expenseAuditor.setExpenseAccountId(expenseId);
		expenseAuditor.setAuditorId(auditorId);

		UserProfile userProfile = userDao.getUserProfile(auditorId);
		if (userProfile != null) {
			expenseAuditor.setAuditorName(userProfile.getUserName());
			expenseAuditor.setAuditorRole(userProfile.getRole());
		}

		List<VeExpenseAuditor> list = expenseAuditorService.getExpenseAuditor(
				expenseId, auditorId);
		if (list == null || list.size() == 0) {
			expenseAuditorService.addExpenseAuditor(expenseAuditor);
		}

		// String mobile = getMobileByExpenseId(expenseId);
		// if (mobile != null && !mobile.equals("")) {
		// String content = "您好，您的中车物流报销单已提交审核!";
		// SmsUtil.sendOutMessage(mobile, content);
		// }
	}

	@Override
	public void commitAll(String userId, String auditorId, String expenseIds) {
		// List<VeExpenseAccount> list = expenseAccountDao
		// .getExpenseBySubmitIdAndStatus(userId,
		// VeExpenseStatusEnum.NOT_COMMITED);
		//
		// expenseAccountDao.commitAll(userId, auditorId);
		// // 更新expense auditor表
		// if (list != null && list.size() > 0) {
		// for (VeExpenseAccount expenseAccount : list) {
		// VeExpenseAuditor expenseAuditor = new VeExpenseAuditor();
		// expenseAuditor.setExpenseAccountId(expenseAccount.getId());
		// expenseAuditor.setAuditorId(auditorId);
		// List<VeExpenseAuditor> auditorList = expenseAuditorService
		// .getExpenseAuditor(expenseAccount.getId(), auditorId);
		// if (auditorList == null || auditorList.size() == 0) {
		// expenseAuditorService.addExpenseAuditor(expenseAuditor);
		// }
		//
		// String mobile = getMobileByExpenseAccount(expenseAccount);
		// if (mobile != null && !mobile.equals("")) {
		// String content = "您好，您的中车物流报销单已提交审核!";
		// SmsUtil.sendOutMessage(mobile, content);
		// }
		// }
		// }

		if (expenseIds != null && expenseIds.length() > 0) {
			String[] expenseIdArray = expenseIds.split(",");
			if (expenseIdArray != null && expenseIdArray.length > 0) {
				for (String expenseId : expenseIdArray) {
					commit(userId, auditorId, Integer.parseInt(expenseId));
				}
			}
		}
	}

	@Override
	public void audit(String fromAuditorId, String toAuditorId, int expenseId,
			int type, int role, String comment) {
		VeExpenseStatusEnum nextStatusEnum = VeExpenseStatusEnum.AUDITING;
		VeUserRoleEnum roleEnum = RoleEnumUtil.convertToEnum(role);
		VeUserRoleEnum nextRoleEnum = roleEnum;
		switch (type) {
		case 0: // 审核不通过，状态置为“审核失败”
			nextStatusEnum = VeExpenseStatusEnum.AUDIT_FAILED;
			nextRoleEnum = roleEnum;
			break;
		case 1: // 审核通过
			switch (roleEnum) {
			case DEPART_LEADER:
				nextStatusEnum = VeExpenseStatusEnum.AUDITING;
				nextRoleEnum = VeUserRoleEnum.PROJECT_LEADER;
				break;
			case PROJECT_LEADER:
				nextStatusEnum = VeExpenseStatusEnum.AUDITING;
				nextRoleEnum = VeUserRoleEnum.MANAGER;
				break;
			case MANAGER:
				nextStatusEnum = VeExpenseStatusEnum.AUDITED;
				nextRoleEnum = roleEnum;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}

		expenseAccountDao.audit(toAuditorId, expenseId, nextStatusEnum,
				nextRoleEnum);
		// 更新comment
		List<VeExpenseAuditor> oldList = expenseAuditorService
				.getExpenseAuditor(expenseId, fromAuditorId);
		if (oldList != null && oldList.size() == 1) {
			VeExpenseAuditor auditor = oldList.get(0);
			auditor.setComments(comment);

			expenseAuditorService.updateExpenseAuditor(auditor);
		}
		// 更新expense auditor表
		VeExpenseAuditor expenseAuditor = new VeExpenseAuditor();
		expenseAuditor.setExpenseAccountId(expenseId);
		expenseAuditor.setAuditorId(toAuditorId);

		UserProfile userProfile = userDao.getUserProfile(toAuditorId);
		if (userProfile != null) {
			expenseAuditor.setAuditorName(userProfile.getUserName());
			expenseAuditor.setAuditorRole(userProfile.getRole());
		}

		List<VeExpenseAuditor> list = expenseAuditorService.getExpenseAuditor(
				expenseId, toAuditorId);
		if (list == null || list.size() == 0) {
			expenseAuditorService.addExpenseAuditor(expenseAuditor);
		}

		switch(roleEnum){
		case MANAGER:
			String mobile = getMobileByExpenseId(expenseId);
			String content = "";
			String startTime = "";
			String endTime = "";
			
			VeExpenseAccount expenseAccount = expenseAccountDao.getExpenseAccount(expenseId);
			if(expenseAccount!=null){
				startTime = expenseAccount.getStartTime();
				endTime = expenseAccount.getEndTime();
			}
			
			if (type == 0) {
				content = "您好，您的中车物流报销单审核不通过 (" + RoleEnumUtil.getRoleValue(role)
						+ "), 出差时间:["+startTime+"--"+endTime+"]!";
			} else {
				content = "您好，您的中车物流报销单审核通过(" + RoleEnumUtil.getRoleValue(role)
						+ "), 出差时间:["+startTime+"--"+endTime+"]!";
			}
			
			SmsUtil.sendOutMessage(mobile, content);
			break;
		default:
			break;
		}
	}

	@Override
	public void auditAll(String fromAuditorId, String toAuditorId, int type,
			int role, String comment, String expenseIds) {
		// VeExpenseStatusEnum nextStatusEnum = VeExpenseStatusEnum.AUDITING;
		// VeUserRoleEnum roleEnum = RoleEnumUtil.convertToEnum(role);
		// VeUserRoleEnum nextRoleEnum = roleEnum;
		// switch (type) {
		// case 0: // 审核不通过，状态置为“审核失败”
		// nextStatusEnum = VeExpenseStatusEnum.AUDIT_FAILED;
		// nextRoleEnum = roleEnum;
		// break;
		// case 1: // 审核通过
		// switch (roleEnum) {
		// case DEPART_LEADER:
		// nextStatusEnum = VeExpenseStatusEnum.AUDITING;
		// nextRoleEnum = VeUserRoleEnum.PROJECT_LEADER;
		// break;
		// case PROJECT_LEADER:
		// nextStatusEnum = VeExpenseStatusEnum.AUDITING;
		// nextRoleEnum = VeUserRoleEnum.MANAGER;
		// break;
		// case MANAGER:
		// nextStatusEnum = VeExpenseStatusEnum.AUDITED;
		// nextRoleEnum = roleEnum;
		// break;
		// default:
		// break;
		// }
		// break;
		// default:
		// break;
		// }
		//
		// List<VeExpenseAccount> list = expenseAccountDao
		// .getExpenseByAuditorIdAndStatus(fromAuditorId,
		// VeExpenseStatusEnum.AUDITING);
		//
		// expenseAccountDao.auditAll(fromAuditorId, toAuditorId,
		// nextStatusEnum,
		// nextRoleEnum);
		//
		// // 更新expense auditor表
		// for (VeExpenseAccount expenseAccount : list) {
		// logger.info("expenseAccountList:" + expenseAccount.getId());
		// // 更新comment
		// List<VeExpenseAuditor> oldList = expenseAuditorService
		// .getExpenseAuditor(expenseAccount.getId(), fromAuditorId);
		// if (oldList != null && oldList.size() == 1) {
		// VeExpenseAuditor auditor = oldList.get(0);
		// logger.info("auditor:" + auditor.getId() + "; "
		// + auditor.getExpenseAccountId());
		// auditor.setComments(comment);
		// expenseAuditorService.updateExpenseAuditor(auditor);
		// }
		//
		// VeExpenseAuditor expenseAuditor = new VeExpenseAuditor();
		// expenseAuditor.setExpenseAccountId(expenseAccount.getId());
		// expenseAuditor.setAuditorId(toAuditorId);
		// List<VeExpenseAuditor> auditorList = expenseAuditorService
		// .getExpenseAuditor(expenseAccount.getId(), toAuditorId);
		// if (auditorList == null || auditorList.size() == 0) {
		// expenseAuditorService.addExpenseAuditor(expenseAuditor);
		// }
		//
		//
		// String mobile = getMobileByExpenseAccount(expenseAccount);
		// if(mobile!=null&&!mobile.equals("")){
		// String content = "";
		// if (type == 0) {
		// content = "您好，您的中车物流报销单审核不通过 (" + RoleEnumUtil.getRoleValue(role)
		// + ")!";
		// } else {
		// content = "您好，您的中车物流报销单审核通过(" + RoleEnumUtil.getRoleValue(role)
		// + ")!";
		// }
		// SmsUtil.sendOutMessage(mobile, content);
		// }
		//
		// }

		if (expenseIds != null && expenseIds.length() > 0) {
			String[] expenseIdArray = expenseIds.split(",");
			if (expenseIdArray != null && expenseIdArray.length > 0) {
				for (String expenseId : expenseIdArray) {
					audit(fromAuditorId, toAuditorId,
							Integer.parseInt(expenseId), type, role, comment);
				}
			}
		}
	}

	@Override
	public String getLatestSn(String currentDay) {
		return expenseAccountDao.getLatestSn(currentDay);
	}

	@Override
	public double getSumAmountBySubmitter(String userId, VeUserRoleEnum role,
			VeExpenseStatusEnum status) {
		return expenseAccountDao.getSumAmountBySubmitter(userId, role, status);
	}

	@Override
	public double getSumAmountBySubmitter(ExpenseSearchVo expenseSearchVo) {
		return expenseAccountDao.getSumAmountBySubmitter(expenseSearchVo);
	}

	@Override
	public double getSumAmountByAuditor(ExpenseSearchVo expenseSearchVo) {
		switch (expenseSearchVo.getStatisticStatus()) {
		case AUDITED:
		case AUDIT_FAILED:
			return expenseAccountDao.getSumAmountByAuditor(expenseSearchVo);
		case AUDITING:
			return expenseAccountDao
					.getSumAmountByAuditorAuditing(expenseSearchVo);
		case WAIT_AUDIT:
			return expenseAccountDao
					.getSumAmountByAuditorWaitAudit(expenseSearchVo);
		default:
			return 0;
		}
	}

	@Override
	public double getSumAmountAll(VeExpenseStatusEnum status) {
		return expenseAccountDao.getSumAmountAll(status);
	}

	@Override
	public double getSumAmountAll(ExpenseSearchVo expenseSearchVo) {
		return expenseAccountDao.getSumAmountAllSearch(expenseSearchVo);
	}

	@Override
	public double getSumAmountByAuditor(String auditorId, VeUserRoleEnum role,
			VeExpenseStatusEnum status) {
		switch (status) {
		case AUDITED:
		case AUDIT_FAILED:
			return expenseAccountDao.getSumAmountByAuditor(auditorId, role,
					status);
		case AUDITING:
			return expenseAccountDao.getSumAmountByAuditorAuditing(auditorId,
					role);
		case WAIT_AUDIT:
			return expenseAccountDao.getSumAmountByAuditorWaitAudit(auditorId,
					role);
		default:
			return 0;
		}
	}

	@Transactional(readOnly = false, rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
	@Override
	public List<VeExpenseAccount> filterExpenseAccount(
			ExpenseSearchVo expenseSearchVo) {
		if (expenseSearchVo.getRole() == VeUserRoleEnum.FINANCE) {
			expenseSearchVo.setUserId(null);
			expenseSearchVo.setStatus(VeExpenseStatusEnum.AUDITED);
			return expenseAccountDao.filterExpenseAccount(expenseSearchVo);
		} else if (expenseSearchVo.getRole() == VeUserRoleEnum.DISPATCHER) {
			return expenseAccountDao.filterExpenseAccount(expenseSearchVo);
		} else {
			System.out.println("stauts:" + expenseSearchVo.getStatus());
			if (expenseSearchVo.getStatus() == VeExpenseStatusEnum.WAIT_AUDIT) {
				return expenseAccountDao
						.filterExpenseAccountWaitAudit(expenseSearchVo);
			} else if (expenseSearchVo.getStatus() == VeExpenseStatusEnum.AUDITING) {
				return expenseAccountDao
						.filterExpenseAccountAuditorAuditing(expenseSearchVo);
			} else {
				return expenseAccountDao.filterExpenseAccount(expenseSearchVo);
			}
		}
	}

	@Override
	public int countExpenseAccount(ExpenseSearchVo expenseSearchVo) {
		int totalCount = 0;
		if (expenseSearchVo.getRole() == VeUserRoleEnum.FINANCE) {
			expenseSearchVo.setUserId(null);
			expenseSearchVo.setStatus(VeExpenseStatusEnum.AUDITED);
			totalCount = expenseAccountDao.countExpenseAccount(expenseSearchVo);
		} else if (expenseSearchVo.getRole() == VeUserRoleEnum.DISPATCHER) {
			totalCount = expenseAccountDao.countExpenseAccount(expenseSearchVo);
		} else {
			System.out.println("stauts:" + expenseSearchVo.getStatus());
			if (expenseSearchVo.getStatus() == VeExpenseStatusEnum.WAIT_AUDIT) {
				totalCount = expenseAccountDao
						.countExpenseAccountWaitAudit(expenseSearchVo);
			} else if (expenseSearchVo.getStatus() == VeExpenseStatusEnum.AUDITING) {
				totalCount = expenseAccountDao
						.countExpenseAccountAuditorAuditing(expenseSearchVo);
			} else {
				totalCount = expenseAccountDao
						.countExpenseAccount(expenseSearchVo);
			}
		}
		logger.info("totalCount:" + totalCount);
		return (totalCount % PAGE_MAX_COUNT) > 0 ? (totalCount / PAGE_MAX_COUNT + 1)
				: totalCount / PAGE_MAX_COUNT;
	}

	public String getMobileByExpenseId(int expenseId) {
		VeExpenseAccount expenseAccount = expenseAccountDao
				.getExpenseAccount(expenseId);
		if (expenseAccount != null) {
			String userId = expenseAccount.getEmployeeId();
			UserProfile user = userDao.getUserProfile(userId);
			if (user != null) {
				String mobile = user.getCellPhoneNumber();
				return mobile;
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public String getMobileByExpenseAccount(VeExpenseAccount expenseAccount) {
		String userId = expenseAccount.getEmployeeId();
		UserProfile user = userDao.getUserProfile(userId);
		if (user != null) {
			String mobile = user.getCellPhoneNumber();
			return mobile;
		} else {
			return null;
		}
	}
	
	*/
}
