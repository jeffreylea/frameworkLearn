package com.dl.location.model.data;

import java.sql.Timestamp;

import com.dl.location.util.ToStringUtil;

public class OperationLogging {
	
	public static final int CustomerTargetType 				= 100;
	public static final int CustomerRechargeTargetType 		= 200;
	public static final int ProductPriceConfigTargetType 	= 300;
	public static final int SalesOrderTargetType 			= 400;
	public static final int SalesOrderStockOutTargetType 	= 500;
	public static final int SalesTypeConfigTargetType 		= 600;
	public static final int StoreOrderStockInTargetType 	= 700;
	public static final int TransportPriceConfigTargetType 	= 800;
	
	private int globalId;
    private Timestamp operationTime;
    private String operatorId;
    private String targetType; 
    private int targetId;
    private String fromValue;
    private String toValue;

    
    
    public int getGlobalId() {
		return globalId;
	}



	public void setGlobalId(int globalId) {
		this.globalId = globalId;
	}



	public Timestamp getOperationTime() {
		return operationTime;
	}



	public void setOperationTime(Timestamp operationTime) {
		this.operationTime = operationTime;
	}



	public String getOperatorId() {
		return operatorId;
	}



	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}



	public String getTargetType() {
		return targetType;
	}



	public void setTargetType(String targetType) {
		this.targetType = targetType;
	}



	public int getTargetId() {
		return targetId;
	}



	public void setTargetId(int targetId) {
		this.targetId = targetId;
	}



	public String getFromValue() {
		return fromValue;
	}



	public void setFromValue(String fromValue) {
		this.fromValue = fromValue;
	}



	public String getToValue() {
		return toValue;
	}



	public void setToValue(String toValue) {
		this.toValue = toValue;
	}



	public String toString() {
    	return ToStringUtil.printPretty(this);
    }

}
