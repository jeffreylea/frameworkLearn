package com.dl.location.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import java.text.ParseException;

public class CalendarUtil {

	 public static final String BLOCK_QUERY_TIME = "00000000";
	 public static final String DateTimeFormatPattern = "yyyyMMdd-HH:mm:ss";

	public static String getYearMonthDayHourMinuteSecond(long utc) {
		SimpleDateFormat formatter = new SimpleDateFormat(DateTimeFormatPattern);
		return formatter.format(new Date(utc));
	}
	    
    /**
     * The method takes as argument an String of the form yyyyMMddHHmm and
     * converts it into TimeStamp(yyyy-mm-dd hh:mm:ss).
     * 
     * @param str
     *        string to be converted should be of the form yyyyMMddHHmm
     * @return the TimeStamp value
     */
    public static Timestamp strToTimestamp(String str) {
        String year = str.substring(0, 4);
        String month = str.substring(4, 6);
        String date = str.substring(6, 8);

        String hourOfDay = str.substring(8, 10);
        String minute = str.substring(10, 12);
        String second = "00";// since seconds is not received in argument
        // so set it to 00.

        String tsStr = year + "-" + month + "-" + date + " " + hourOfDay + ":" + minute + ":" + second;
        Timestamp ts = Timestamp.valueOf(tsStr);
        return ts;
    }
    
    public static Timestamp getTimestampInstance(Calendar cal, boolean useCurrTimeWhenNull) {
        Timestamp ts = null;
        if (cal != null) {
            ts = new Timestamp(cal.getTimeInMillis());
        }
        else {
            if (useCurrTimeWhenNull)
                ts = new Timestamp(System.currentTimeMillis());
            else
                ts = new Timestamp(0);
        }
        return ts;
    }
    
    public static Calendar getCalendarInstance(Timestamp ts, boolean useCurrTimeWhenNull) {
        GregorianCalendar gc = new GregorianCalendar(TimeZone.getDefault());
        if (ts != null) {
            gc.setTimeInMillis(ts.getTime());
        }
        else {
            if (useCurrTimeWhenNull)
                gc.setTimeInMillis(System.currentTimeMillis());
            else
                gc.setTimeInMillis(0);
        }
        return gc;
    }
    
    public static long getDaysBetweenCalendar(Calendar first, Calendar second){
    	long days=0;
    	long firstDays=first.get(Calendar.YEAR)*365 + first.get(Calendar.DAY_OF_YEAR);
    	long secondDays=second.get(Calendar.YEAR)*365 + second.get(Calendar.DAY_OF_YEAR);
    	days= firstDays - secondDays;
    	return days;
    }

    public static Date getDateInstance(Calendar cal) {
        Date date = null;
        if (cal != null) {
            date = new Date();
            date.setTime(cal.getTimeInMillis());
        }
        else {
            date = new Date(0);
        }
        return date;
    }

    public static String getCurrentYearMonthDay() {
    	Date date = new Date(System.currentTimeMillis());
    	SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
    	return sdf.format(date);
    }
    
    public static String getCurrentYearMonthDayByFormat(String format) {
    	Date date = new Date(System.currentTimeMillis());
    	SimpleDateFormat sdf = new SimpleDateFormat(format);
    	return sdf.format(date);
    }
    
    
    public static Calendar getCalendarInstance(Date dt) {
        GregorianCalendar gc = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        if (dt != null) {
            gc.setTimeInMillis(dt.getTime());
        }
        else {
            gc.setTimeInMillis((new Date(0)).getTime());
        }
        return gc;
    }

    public static Calendar getCalendarInstance(long milliSec) {
        GregorianCalendar gc = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        if (milliSec >= 0) {
            gc.setTimeInMillis(milliSec);
        }
        else {
            gc.setTimeInMillis(0);
        }
        return gc;
    }

    public static Calendar getGMTCalendarInstance(Date dt) {
        GregorianCalendar gc = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        if (dt != null) {
            gc.setTimeInMillis(dt.getTime());
        }
        else {
            gc.setTimeInMillis((new Date(0)).getTime());
        }
        return gc;
    }
    
    public static long getTimeSubedOffset(long timeStamp) {
        return timeStamp - TimeZone.getDefault().getOffset(timeStamp);
    }

    public static long getTimeAddedOffset(long timeStamp) {
        return timeStamp + TimeZone.getDefault().getOffset(timeStamp);
    }

    public static boolean isSameDay(long date1, long date2) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String str1 = df.format(date1);
        String str2 = df.format(date2);

        return StringUtil.equalsIgnoreCaseWithNull(str1, str2);
    }
    

    public static Date changetoGMT(Date date) {
		long longdata = date.getTime();
		int lcmTzOffset = TimeZone.getDefault().getOffset(longdata);

		return(new Date(longdata - lcmTzOffset));
	}
    public static Date changeFromGMT(Date date) {
		long longDate = date.getTime();
		int lcmTzOffset = TimeZone.getDefault().getOffset(longDate);

		return(new Date(longDate + lcmTzOffset));
	}
    
    public static String toExpiredTime(long date) {
    	String expireTime = null;
    	if (date > 0){
    		SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmm");
    		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
    		expireTime = sdf.format(new Date(date));
    	}
    	else {
    		expireTime=BLOCK_QUERY_TIME;
    	}
        return expireTime;
    }
    
    //Change the String from UTC to the local time zone UTC.
    public static String changeFromGMTStr(String tmp)
    {
     	 SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
    	try {
   			Date date = sdf.parse(tmp);
  			return sdf.format(changeFromGMT(date));
   		} catch (ParseException e) {
   			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
   			return null;
    }
    
    public static long getBeforeDate(int dates) {
		Date date = new Date(System.currentTimeMillis());
		Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
		calendar.setTime(date);
		calendar.add(calendar.DATE, -dates);
		return calendar.getTimeInMillis();
	}
    
    public static long strToTimeMillis(String str) {
    	long timeMills = 0;
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    	try {
			Date date = sdf.parse(str);
			Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
			calendar.setTime(date);
			timeMills = calendar.getTimeInMillis();
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	return timeMills;
    }
}
