package com.dl.location.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

public interface ExpenseAccountDao {

	/*
	public int addExpenseAccount(
			@Param("expenseAccount") VeExpenseAccount expenseAccount);

	public int getAutoId();

	public String getLatestSn(@Param("currentDay") String currentDay);
	
	public double getSumAmountAll(@Param("status") VeExpenseStatusEnum status);
	public double getSumAmountAllSearch(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);

	public double getSumAmountBySubmitter(@Param("userId") String userId,
			@Param("role") VeUserRoleEnum role,
			@Param("status") VeExpenseStatusEnum status);
	
	public double getSumAmountBySubmitter(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	
	public double getSumAmountByAuditor(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	
	public double getSumAmountByAuditorAuditing(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);

	public double getSumAmountByAuditorWaitAudit(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);


	public double getSumAmountByAuditor(@Param("auditorId") String auditorId,
			@Param("role") VeUserRoleEnum role,
			@Param("status") VeExpenseStatusEnum status);

	public double getSumAmountByAuditorAuditing(
			@Param("auditorId") String auditorId,
			@Param("role") VeUserRoleEnum role);

	public double getSumAmountByAuditorWaitAudit(
			@Param("auditorId") String auditorId,
			@Param("role") VeUserRoleEnum role);

	public void updateExpenseAccount(
			@Param("expenseAccount") VeExpenseAccount expenseAccount);

	public VeExpenseAccount getExpenseAccount(@Param("id") int id);

	public List<VeExpenseAccount> getExpenseAccountList(
			@Param("userId") String userId, @Param("role") VeUserRoleEnum role, @Param("start") int start,
			@Param("count") int count);
	public int getExpenseAccountListCount(
			@Param("userId") String userId,@Param("role") VeUserRoleEnum role);
	
	//for finance
	public List<VeExpenseAccount> getExpenseAccountListAll(@Param("start") int start,
			@Param("count") int count);
	public int getExpenseAccountListCountAll();

	public List<VeExpenseAccount> getExpenseAccountListByStatus(
			@Param("status") VeExpenseStatusEnum status,
			@Param("userId") String userId, @Param("role") VeUserRoleEnum role, @Param("start") int start,
			@Param("count") int count);
	public int getExpenseAccountListCountByStatus(
			@Param("status") VeExpenseStatusEnum status,
			@Param("userId") String userId, @Param("role") VeUserRoleEnum role);
	
	//for finance
	public List<VeExpenseAccount> getExpenseAccountListByStatusAll(
			@Param("status") VeExpenseStatusEnum status, @Param("start") int start,
			@Param("count") int count);
	public int getExpenseAccountListCountByStatusAll(
			@Param("status") VeExpenseStatusEnum status);

	public List<VeExpenseAccount> getExpenseAccountListByVehicleNum(
			@Param("vehicleNum") String vehicleNum);

	public List<VeExpenseAccount> getExpenseAccountListByCreateDate(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role,
			@Param("start") int start, @Param("count") int count);
	public int getExpenseAccountListCountByCreateDate(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role);
	
	//for finance
	public List<VeExpenseAccount> getExpenseAccountListByCreateDateAll(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate,
			@Param("start") int start, @Param("count") int count);
	public int getExpenseAccountListCountByCreateDateAll(
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate);

	public List<VeExpenseAccount> getExpenseAccountListByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role,
			@Param("start") int start, @Param("count") int count);
	public int getExpenseAccountListCountByStatusAndCreateDate(
			@Param("status") VeExpenseStatusEnum status,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("userId") String userId,
			@Param("role") VeUserRoleEnum role);
	
	//for finance
	public List<VeExpenseAccount> getExpenseAccountListByStatusAndCreateDateAll(
			@Param("status") VeExpenseStatusEnum status,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate,
			@Param("start") int start, @Param("count") int count);
	public int getExpenseAccountListCountByStatusAndCreateDateAll(
			@Param("status") VeExpenseStatusEnum status,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate);

	public List<VeExpenseVo> getExpenseVoListBySubmitId(@Param("expenseSearchVo") ExpenseSearchVo vo);

	public List<VeExpenseVo> getExpenseVoListByStatus(@Param("expenseSearchVo") ExpenseSearchVo vo);

	public List<VeExpenseVo> getExpenseVoListByStatusAuditing(@Param("expenseSearchVo") ExpenseSearchVo vo);

	public List<VeExpenseVo> getExpenseVoListByStatusWaitAudit(@Param("expenseSearchVo") ExpenseSearchVo vo);

	public void commit(@Param("auditorId") String auditorId,
			@Param("expenseId") int expenseId);

	public void commitAll(@Param("userId") String userId,
			@Param("auditorId") String auditorId);

	public void audit(@Param("auditorId") String auditorId,
			@Param("expenseId") int expenseId,
			@Param("status") VeExpenseStatusEnum statusEnum,
			@Param("role") VeUserRoleEnum roleEnum);

	public void auditAll(@Param("fromAuditorId") String fromAuditorId,
			@Param("toAuditorId") String toAuditorId,
			@Param("status") VeExpenseStatusEnum statusEnum,
			@Param("role") VeUserRoleEnum roleEnum);

	public List<VeExpenseAccount> getExpenseByAuditorIdAndStatus(
			@Param("auditorId") String auditorId,
			@Param("status") VeExpenseStatusEnum statusEnum);

	public List<VeExpenseAccount> getExpenseBySubmitIdAndStatus(
			@Param("submitterId") String submitterId,
			@Param("status") VeExpenseStatusEnum status);
	
	public List<VeExpenseAccount> filterExpenseAccount(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	public int countExpenseAccount(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	
	public List<VeExpenseAccount> filterExpenseAccountAuditorAuditing(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	public int countExpenseAccountAuditorAuditing(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	
	public List<VeExpenseAccount> filterExpenseAccountWaitAudit(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	public int countExpenseAccountWaitAudit(@Param("expenseSearchVo") ExpenseSearchVo expenseSearchVo);
	
	*/
}