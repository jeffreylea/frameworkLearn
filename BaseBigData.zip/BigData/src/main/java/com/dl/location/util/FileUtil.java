package com.dl.location.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
    
    public static long getLastModifiedUtc(String filePath) {
        File file = new File(filePath);
        return file.lastModified();
    }
    
    public static List<String> readInputByRow(String filePath) {
        List<String> list = new ArrayList<String>();
        File file = new File(filePath);
        FileInputStream fis = null;
        InputStreamReader isr = null;
        BufferedReader reader = null;
        try {
            fis = new FileInputStream(file);
            isr = new InputStreamReader(fis);
            reader = new BufferedReader(isr);
            String tempstring = null;
            while ((tempstring = reader.readLine()) != null) {
                list.add(tempstring);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            MiscUtil.close(reader);
            MiscUtil.close(isr);
            MiscUtil.close(fis);
        }
        return list;
    }

}
