package com.dl.location.util;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.Charset;

public class ByteUtil {

    public static byte[] stringToUtf8Byte(String value) {
        return value.getBytes(Charset.forName("UTF-8"));
    }
    
    public static byte[] shortToByte(short value) {
        ByteBuffer bb = ByteBuffer.allocate(2);
        byte[] ret = new byte[2];
        ShortBuffer lb = bb.asShortBuffer();
        lb.put(value);
        bb.get(ret);
        return ret;
    }
    
    public static byte[] intToByte(int value, int length) {
        ByteBuffer bb = ByteBuffer.allocate(length);
        byte[] ret = new byte[length];
        IntBuffer lb = bb.asIntBuffer();
        lb.put(value);
        bb.get(ret);
        return ret;
    }
    
    public static byte[] doubleToByte(double dbl1) {
        ByteBuffer bb = ByteBuffer.allocate(8);
        byte[] ret = new byte[8];
        DoubleBuffer fb = bb.asDoubleBuffer();
        fb.put(dbl1);
        bb.get(ret);
        return ret;
    }

    public static byte[] longToByte(long ld) {
        ByteBuffer bb = ByteBuffer.allocate(8);
        byte[] ret = new byte[8];
        LongBuffer lb = bb.asLongBuffer();
        lb.put(ld);
        bb.get(ret);
        return ret;
    }

//    public static byte[] intToByte(int id) {
//        ByteBuffer bb = ByteBuffer.allocate(4);
//        byte[] ret = new byte[4];
//        IntBuffer lb = bb.asIntBuffer();
//        lb.put(id);
//        bb.get(ret);
//        return ret;
//    }

    public static double byteToDouble(byte[] v) {
        ByteBuffer bb = ByteBuffer.wrap(v);
        return toDouble(bb);
    }

    public static double byteToDouble(byte[] v, int fromLocation, int length) {
        ByteBuffer bb = ByteBuffer.wrap(v, fromLocation, length);
        return toDouble(bb);
    }
    
    public static double toDouble(ByteBuffer bb) {
        DoubleBuffer fb = bb.asDoubleBuffer();
        return fb.get();
    }

    public static float byteToFloat(byte[] v) {
        ByteBuffer bb = ByteBuffer.wrap(v);
        return toFloat(bb);
    }

    public static float byteToFloat(byte[] v, int fromLocation, int length) {
        ByteBuffer bb = ByteBuffer.wrap(v, fromLocation, length);
        return toFloat(bb);
    }
    
    public static float toFloat(ByteBuffer bb) {
        FloatBuffer fb = bb.asFloatBuffer();
        return  fb.get();
    }
    
    public static long byteToLong(byte[] source, int fromLocation, int length) {
        ByteBuffer bb = ByteBuffer.wrap(source, fromLocation, length);
        return toLong(bb);
    }
    
    public static long byteToLong(byte[] v) {
        ByteBuffer bb = ByteBuffer.wrap(v);
        return toLong(bb);
    }

    public static long toLong(ByteBuffer bb) {
        LongBuffer fb = bb.asLongBuffer();
        return fb.get();
    }

    public static int byteToInt(byte[] source, int fromLocation, int length) {
        ByteBuffer bb = ByteBuffer.wrap(source, fromLocation, length);
        return toInt(bb);
    }
    
    public static int byteToInt(byte[] v) {
        ByteBuffer bb = ByteBuffer.wrap(v);
        return toInt(bb);
    }
    
    public static short byteToShort(byte[] source, int fromLocation, int length) {
        ByteBuffer bb = ByteBuffer.wrap(source, fromLocation, length);
        ShortBuffer sb = bb.asShortBuffer();
        return sb.get();
    }
//    
//    public static short byteToShort(byte[] v) {
//        ByteBuffer bb = ByteBuffer.wrap(v);
//        ShortBuffer sb = bb.asShortBuffer();
//        return sb.get();
//    }

    public static int toInt(ByteBuffer bb) {
        IntBuffer fb = bb.asIntBuffer();
        return fb.get();
    }

    public static String toString(byte[] v) {
        ByteBuffer bb = ByteBuffer.wrap(v);
        CharBuffer fb = bb.asCharBuffer();
        return fb.toString();
    }
    
    public static String toHexStr(byte[] bytes) {
		if(bytes == null) {
			return "";
		}
		StringBuffer sbuf = new StringBuffer();

		for(byte b :bytes) {
			sbuf.append(String.format("%02x", b));
		}

		return sbuf.toString();
		
//    	for (byte b: bytes) {
//    		sbuf.append("0123456789ABCDEF".charAt(b >> 4 & 0xF));
//    		sbuf.append("0123456789ABCDEF".charAt(b & 0xF));
//    	}
//    	return sb.toString();
    }

    public int getUnsignedByte(byte data) {
        return data & 0xFF;
    }

    public int getUnsignedShort(short data) {
        return data & 0xFFFF;
    }

    public long getUnsignedInt(int data) {
        return data & 0xFFFFFFFFl;
    }

    public static void main(String[] args) {
    }

}
