package com.dl.location.aop;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.dl.location.api.ApiValue;

@Component
@Aspect
public class EduPlatformAspect {
	
	@Around("execution (public com.dl.location.api.ApiValue com.dl.location.*.*(..))")
	public Object wrapApiValue(ProceedingJoinPoint jp) {
		Object result = null;
		try {
			result = jp.proceed();
			System.out.println("AOP result:"+result);
		} catch (Throwable e) {
			System.out.println("AOP exception");
			return new ApiValue(-1, e.getMessage());
		}
		return result;
	}
}
