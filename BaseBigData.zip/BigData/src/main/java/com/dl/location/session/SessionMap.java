package com.dl.location.session;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SessionMap implements Serializable {
	
	private static final long serialVersionUID = -3634443970310298159L;
	private final Map<String, Object> container = new ConcurrentHashMap<String, Object>();
	
	public Object getAttribute(String key) {
		return container.get(key);
	}
	
	public void setAttribute(String key, Object value) {
		container.put(key, value);
	}
}
