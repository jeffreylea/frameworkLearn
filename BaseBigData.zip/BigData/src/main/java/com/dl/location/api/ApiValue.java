package com.dl.location.api;

public class ApiValue {
	
	private int errCode;
	private String errMsg;
	private Object value;
	
	public ApiValue(){
		super();
	}
	public ApiValue(int errCode, String errMsg) {
		super();
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public ApiValue(Object value) {
		super();
		this.value = value;
	}

	public int getErrCode() {
		return errCode;
	}

	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}
