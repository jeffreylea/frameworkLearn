package com.dl.location.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.dl.location.admin.data.Product;
import com.dl.location.admin.data.ProductLocation;
import com.dl.location.dao.LocationDao;

import com.dl.location.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService {
	@Autowired
	private LocationDao locationDao;
	@Override
	public List<Product> getproduct() {
		// TODO Auto-generated method stub
		List<Product> list = locationDao.getproduct();
		return list;
	}
	public List<Product> getbrand(@Param("product") String product ){
		List<Product> list = locationDao.getbrand(product);
		return list;
	}
	
	@Override
	public List<ProductLocation> getLocation() {
		// TODO Auto-generated method stub
		List<ProductLocation> list = locationDao.getLocation();
		return list;
	}

} 
