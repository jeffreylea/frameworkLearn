//
// 此文件是由 JavaTM Architecture for XML Binding (JAXB) 引用实现 v2.2.5-2 生成的
// 请访问 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 在重新编译源模式时, 对此文件的所有修改都将丢失。
// 生成时间: 2017.05.11 时间 03:01:19 PM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://location.dl.com/admin/data")
package com.dl.location.admin.data;
