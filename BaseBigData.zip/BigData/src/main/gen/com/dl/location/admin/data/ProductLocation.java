//
// 此文件是由 JavaTM Architecture for XML Binding (JAXB) 引用实现 v2.2.5-2 生成的
// 请访问 <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// 在重新编译源模式时, 对此文件的所有修改都将丢失。
// 生成时间: 2017.05.11 时间 03:01:19 PM CST 
//


package com.dl.location.admin.data;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import org.jvnet.jaxb2_commons.lang.Equals;
import org.jvnet.jaxb2_commons.lang.EqualsStrategy;
import org.jvnet.jaxb2_commons.lang.HashCode;
import org.jvnet.jaxb2_commons.lang.HashCodeStrategy;
import org.jvnet.jaxb2_commons.lang.JAXBEqualsStrategy;
import org.jvnet.jaxb2_commons.lang.JAXBHashCodeStrategy;
import org.jvnet.jaxb2_commons.lang.JAXBToStringStrategy;
import org.jvnet.jaxb2_commons.lang.ToString;
import org.jvnet.jaxb2_commons.lang.ToStringStrategy;
import org.jvnet.jaxb2_commons.locator.ObjectLocator;
import org.jvnet.jaxb2_commons.locator.util.LocatorUtils;


/**
 * <p>ProductLocation complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ProductLocation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="sale" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cityName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lngLat" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="date" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductLocation", propOrder = {
    "id",
    "sale",
    "cityName",
    "lngLat",
    "date"
})
public class ProductLocation
    implements Serializable, Equals, HashCode, ToString
{

    private final static long serialVersionUID = 1L;
    protected int id;
    @XmlElement(required = true)
    protected String sale;
    @XmlElement(required = true)
    protected String cityName;
    @XmlElement(required = true)
    protected String lngLat;
    @XmlElement(required = true)
    protected String date;

    /**
     * 获取id属性的值。
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * 设置id属性的值。
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

    public boolean isSetId() {
        return true;
    }

    /**
     * 获取sale属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSale() {
        return sale;
    }

    /**
     * 设置sale属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSale(String value) {
        this.sale = value;
    }

    public boolean isSetSale() {
        return (this.sale!= null);
    }

    /**
     * 获取cityName属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * 设置cityName属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    public boolean isSetCityName() {
        return (this.cityName!= null);
    }

    /**
     * 获取lngLat属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLngLat() {
        return lngLat;
    }

    /**
     * 设置lngLat属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLngLat(String value) {
        this.lngLat = value;
    }

    public boolean isSetLngLat() {
        return (this.lngLat!= null);
    }

    /**
     * 获取date属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDate() {
        return date;
    }

    /**
     * 设置date属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(String value) {
        this.date = value;
    }

    public boolean isSetDate() {
        return (this.date!= null);
    }

    public String toString() {
        final ToStringStrategy strategy = JAXBToStringStrategy.INSTANCE;
        final StringBuilder buffer = new StringBuilder();
        append(null, buffer, strategy);
        return buffer.toString();
    }

    public StringBuilder append(ObjectLocator locator, StringBuilder buffer, ToStringStrategy strategy) {
        strategy.appendStart(locator, this, buffer);
        appendFields(locator, buffer, strategy);
        strategy.appendEnd(locator, this, buffer);
        return buffer;
    }

    public StringBuilder appendFields(ObjectLocator locator, StringBuilder buffer, ToStringStrategy strategy) {
        {
            int theId;
            theId = (this.isSetId()?this.getId(): 0);
            strategy.appendField(locator, this, "id", buffer, theId);
        }
        {
            String theSale;
            theSale = this.getSale();
            strategy.appendField(locator, this, "sale", buffer, theSale);
        }
        {
            String theCityName;
            theCityName = this.getCityName();
            strategy.appendField(locator, this, "cityName", buffer, theCityName);
        }
        {
            String theLngLat;
            theLngLat = this.getLngLat();
            strategy.appendField(locator, this, "lngLat", buffer, theLngLat);
        }
        {
            String theDate;
            theDate = this.getDate();
            strategy.appendField(locator, this, "date", buffer, theDate);
        }
        return buffer;
    }

    public boolean equals(ObjectLocator thisLocator, ObjectLocator thatLocator, Object object, EqualsStrategy strategy) {
        if (!(object instanceof ProductLocation)) {
            return false;
        }
        if (this == object) {
            return true;
        }
        final ProductLocation that = ((ProductLocation) object);
        {
            int lhsId;
            lhsId = (this.isSetId()?this.getId(): 0);
            int rhsId;
            rhsId = (that.isSetId()?that.getId(): 0);
            if (!strategy.equals(LocatorUtils.property(thisLocator, "id", lhsId), LocatorUtils.property(thatLocator, "id", rhsId), lhsId, rhsId)) {
                return false;
            }
        }
        {
            String lhsSale;
            lhsSale = this.getSale();
            String rhsSale;
            rhsSale = that.getSale();
            if (!strategy.equals(LocatorUtils.property(thisLocator, "sale", lhsSale), LocatorUtils.property(thatLocator, "sale", rhsSale), lhsSale, rhsSale)) {
                return false;
            }
        }
        {
            String lhsCityName;
            lhsCityName = this.getCityName();
            String rhsCityName;
            rhsCityName = that.getCityName();
            if (!strategy.equals(LocatorUtils.property(thisLocator, "cityName", lhsCityName), LocatorUtils.property(thatLocator, "cityName", rhsCityName), lhsCityName, rhsCityName)) {
                return false;
            }
        }
        {
            String lhsLngLat;
            lhsLngLat = this.getLngLat();
            String rhsLngLat;
            rhsLngLat = that.getLngLat();
            if (!strategy.equals(LocatorUtils.property(thisLocator, "lngLat", lhsLngLat), LocatorUtils.property(thatLocator, "lngLat", rhsLngLat), lhsLngLat, rhsLngLat)) {
                return false;
            }
        }
        {
            String lhsDate;
            lhsDate = this.getDate();
            String rhsDate;
            rhsDate = that.getDate();
            if (!strategy.equals(LocatorUtils.property(thisLocator, "date", lhsDate), LocatorUtils.property(thatLocator, "date", rhsDate), lhsDate, rhsDate)) {
                return false;
            }
        }
        return true;
    }

    public boolean equals(Object object) {
        final EqualsStrategy strategy = JAXBEqualsStrategy.INSTANCE;
        return equals(null, null, object, strategy);
    }

    public int hashCode(ObjectLocator locator, HashCodeStrategy strategy) {
        int currentHashCode = 1;
        {
            int theId;
            theId = (this.isSetId()?this.getId(): 0);
            currentHashCode = strategy.hashCode(LocatorUtils.property(locator, "id", theId), currentHashCode, theId);
        }
        {
            String theSale;
            theSale = this.getSale();
            currentHashCode = strategy.hashCode(LocatorUtils.property(locator, "sale", theSale), currentHashCode, theSale);
        }
        {
            String theCityName;
            theCityName = this.getCityName();
            currentHashCode = strategy.hashCode(LocatorUtils.property(locator, "cityName", theCityName), currentHashCode, theCityName);
        }
        {
            String theLngLat;
            theLngLat = this.getLngLat();
            currentHashCode = strategy.hashCode(LocatorUtils.property(locator, "lngLat", theLngLat), currentHashCode, theLngLat);
        }
        {
            String theDate;
            theDate = this.getDate();
            currentHashCode = strategy.hashCode(LocatorUtils.property(locator, "date", theDate), currentHashCode, theDate);
        }
        return currentHashCode;
    }

    public int hashCode() {
        final HashCodeStrategy strategy = JAXBHashCodeStrategy.INSTANCE;
        return this.hashCode(null, strategy);
    }

}
