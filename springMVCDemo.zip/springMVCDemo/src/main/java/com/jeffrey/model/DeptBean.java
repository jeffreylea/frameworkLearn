package com.jeffrey.model;

/**
 * @author lijianfei
 * @2018年8月14日
 * email:1020724110@qq.com
 */
public class DeptBean {
	private int deptid;
	 private String deptname;
	 private String remark;
	 public DeptBean() {
	  super();
	 }
	 public DeptBean(int deptid, String deptname, String remark) {
	  super();
	  this.deptid = deptid;
	  this.deptname = deptname;
	  this.remark = remark;
	 }
	 public int getDeptid() {
	  return deptid;
	 }
	 public void setDeptid(int deptid) {
	  this.deptid = deptid;
	 }
	 public String getDeptname() {
	  return deptname;
	 }
	 public void setDeptname(String deptname) {
	  this.deptname = deptname;
	 }
	 public String getRemark() {
	  return remark;
	 }
	 public void setRemark(String remark) {
	  this.remark = remark;
	 }


}
