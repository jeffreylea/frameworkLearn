package com.jeffrey.utils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author lijianfei
 * @2018年8月14日
 * email:1020724110@qq.com
 */
public class SpringUtil {
	// 定义属性
	 private static ApplicationContext context;
	 // 读取配置文件
	 static {
	  context = new ClassPathXmlApplicationContext("spring/spring-mvc.xml");
	 }
	 
	 // 定义一个方法，判断bean是否为空，如果不为空的，获取这个bean
	 public static Object getBean(String beanName) {
	  // 定义一个空对象
	  Object obj = null;
	  // 如果beanName不为空的话，那么根据这个beanName获取到bean对象，赋值给obj并返回
	  if (beanName != null && !beanName.equals("")) {
	   obj = context.getBean(beanName);
	  }
	  return obj;
	 }


}
