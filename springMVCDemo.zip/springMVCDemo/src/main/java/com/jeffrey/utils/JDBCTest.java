package com.jeffrey.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mysql.jdbc.Statement;


/**
 * @author lijianfei
 * @2018年8月14日
 * email:1020724110@qq.com
 */
public class JDBCTest {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring/spring-mvc.xml");
		 /*
		   * 本来需要用applicationContext获取到我们的bean对象，
		   * 这里使用工厂类的方法将之独立出来，具体使用见SpringUtil.java
		   */
		DataSource datasource=context.getBean("dataSource",DataSource.class);
		 // DataSource datasource=(DataSource)SpringUtil.getBean("dataSource");
		  Connection conn=null;
		  Statement stmt = null;
		  ResultSet rs = null;
		  String sql = "select * from user";
		  try{
		   conn=datasource.getConnection();
		   stmt = (Statement) conn.createStatement();
		   rs = stmt.executeQuery(sql);
		   while (rs.next()) {
			    System.out.println(rs.getInt("user_id") + "\t" + rs.getString("user_name") + "\t"
			      + rs.getString("user_password") + "\t" + rs.getString("user_address"));
			   }
		  }catch(SQLException e){
		   e.printStackTrace();
		  }
		  System.out.println(conn);//测试是否能够输出连接

	}

}
