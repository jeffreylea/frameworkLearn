package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;


@Service
public class HelloService {

	@Autowired
    RestTemplate restTemplate;
	@HystrixCommand(fallbackMethod="serviceFallback")//加入HystrixCommand实现断路
    public String hiService(String name) {
    	//ribbon会根据服务名来选择具体的服务实例，根据服务实例在请求的时候会用具体的url替换掉服务名，实现了负载均衡
        return restTemplate.getForObject("http://HELLO-SERVICE/hi?name="+name,String.class);
    }
	
	public String serviceFallback(String name) {
		return "hi,"+name+",sorry,error!";
		
	}


}
