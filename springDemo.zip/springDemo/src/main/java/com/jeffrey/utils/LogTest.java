package com.jeffrey.utils;

import org.apache.log4j.Logger;

/**
 * @author lijianfei
 * @2018年8月14日
 * email:1020724110@qq.com
 */
public class LogTest {
	private static final Logger log = Logger.getLogger(LogTest.class);
	public static void main(String[] args) {
		log.info("aaaaa");

		
	}
	

}
