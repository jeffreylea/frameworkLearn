package com.jeffrey.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jeffrey.utils.LogTest;

/**
 * @author lijianfei
 * @2018��8��8��
 * email:1020724110@qq.com
 */
@RestController
@RequestMapping("/jeffrey" )
public class controller {
	private static final Logger log = Logger.getLogger(controller.class);
	/**
	 * @param args
	 */
	 @RequestMapping(value = "hello", method = {RequestMethod.GET,RequestMethod.POST})
     @ResponseBody
     public String helloWorld(@RequestParam ("user") String userName) {
		 log.info(userName);
            return "Hello " + userName + " !" ;
            
    }
}
