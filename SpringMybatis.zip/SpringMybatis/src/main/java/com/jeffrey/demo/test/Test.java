package com.jeffrey.demo.test;

import java.util.List;

import com.jeffrey.demo.dao.BookTypeDAO;
import com.jeffrey.demo.entities.BookType;
import com.jeffrey.demo.service.BookTypeDAOService;
import com.jeffrey.demo.serviceImpl.BookTypeDAOServiceImpl;

/**
 * @author lijianfei
 * @2018年8月15日
 * email:1020724110@qq.com
 */
public class Test {
	
	public static void main(String[] args) {
		BookTypeDAOService aa=null;
		List<BookType> list=aa.getAllBookTypes();
		for(BookType bookType:list)
			System.out.println(bookType.getTypeName());
	}

}
