package com.jeffrey.demo.serviceImpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jeffrey.demo.dao.BookTypeDAO;
import com.jeffrey.demo.entities.BookType;
import com.jeffrey.demo.service.BookTypeDAOService;

/**
 * @author lijianfei
 * @2018年8月15日
 * email:1020724110@qq.com
 */
@Service
public class BookTypeDAOServiceImpl implements BookTypeDAOService {
	@Resource
	private BookTypeDAO bookTypeDao;

	@Override
	public List<BookType> getAllBookTypes() {
		// TODO Auto-generated method stub
		List<BookType> bookTypes=bookTypeDao.getAllBookTypes();
		return bookTypes;
	}

}
