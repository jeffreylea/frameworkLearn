package com.jeffrey.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jeffrey.demo.dao.BookTypeDAO;
import com.jeffrey.demo.entities.BookType;
import com.jeffrey.demo.serviceImpl.BookTypeDAOServiceImpl;


/**
 * @author lijianfei
 * @2018��8��8��
 * email:1020724110@qq.com
 */
@RestController
@RequestMapping("/jeffrey" )
public class DemoController {
	@Autowired
	 private BookTypeDAOServiceImpl bookTypeDAOService;
		
	private static final Logger log = Logger.getLogger(DemoController.class);
	/**
	 * @param args
	 */
	
	 @RequestMapping(value = "hello", method = {RequestMethod.GET,RequestMethod.POST})
     @ResponseBody
     public String helloWorld(@RequestParam("user")String user) {
		 //HttpServletRequest request,Model model
		// request.getParameter("id")
		 List<BookType> list=bookTypeDAOService.getAllBookTypes();
		 for(BookType bookType:list)
				System.out.println(bookType.getTypeName());
		 log.info("hhhh");
            return "Hello " + user + " !" ;            
    }
	 public static void main(String[] args) {
		 
	}
}
