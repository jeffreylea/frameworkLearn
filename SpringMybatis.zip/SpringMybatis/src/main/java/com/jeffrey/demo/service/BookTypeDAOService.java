package com.jeffrey.demo.service;

import java.util.List;

import com.jeffrey.demo.entities.BookType;

/**
 * @author lijianfei
 * @2018年8月15日
 * email:1020724110@qq.com
 */
public interface BookTypeDAOService {
	public List<BookType> getAllBookTypes();

}
