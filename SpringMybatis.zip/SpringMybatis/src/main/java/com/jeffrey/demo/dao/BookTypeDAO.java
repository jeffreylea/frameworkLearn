package com.jeffrey.demo.dao;

import java.util.List;

import com.jeffrey.demo.entities.BookType;

/**
 * @author lijianfei
 * @2018年8月14日
 * email:1020724110@qq.com
 */
public interface BookTypeDAO {
	/*
     * 获得所有图书类型
     */
    public List<BookType> getAllBookTypes();

}
