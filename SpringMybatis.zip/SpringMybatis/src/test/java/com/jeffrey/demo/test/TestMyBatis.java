package com.jeffrey.demo.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.jeffrey.demo.entities.BookType;
import com.jeffrey.demo.service.BookTypeDAOService;

public class TestMyBatis {
	private BookTypeDAOService bookTypeDAOService;

	@Test
	public void test() {
		List<BookType> list=bookTypeDAOService.getAllBookTypes();
		for(BookType bookType:list)
			System.out.println(bookType.getTypeName());
	}

}
