package com.bairuitech.anychat;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.security.MessageDigest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class AnyChatSignUtils
{
  private static String PRIVATE_KEY = "";

  private static String PUBLIC_KEY = "";
  private static String APP_ID = "";

  private static String MD5_KEY = "";
  private static String OVER_TIME_TEMP = "";

  private static int OVER_TIME = 0;

  static {
    try {
      Properties pro = new Properties();
      InputStream in = AnyChatSignUtils.class.getResourceAsStream("configInfo.properties");
      pro.load(in);
      APP_ID = pro.getProperty("appId");
      MD5_KEY = pro.getProperty("md5key");
      OVER_TIME_TEMP = pro.getProperty("timestamp");
      if ((OVER_TIME_TEMP != null) && (OVER_TIME_TEMP != ""))
        OVER_TIME = Integer.parseInt(OVER_TIME_TEMP);
      else {
        OVER_TIME = 60;
      }

      InputStream publicKey = AnyChatSignUtils.class.getResourceAsStream("public.pem");
      InputStream privateKey = AnyChatSignUtils.class.getResourceAsStream("private.pem");
      PRIVATE_KEY = loadKey(privateKey);
      PUBLIC_KEY = loadKey(publicKey);
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }

  private static String loadKey(InputStream in) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(in));
    String readLine = null;
    StringBuilder sb = new StringBuilder();

    while ((readLine = br.readLine()) != null) {
      sb.append(readLine);
      sb.append('\r');
      sb.append('\n');
    }

    return sb.toString();
  }

  public static SignResult getRsaSign(String userName, String appid) {
    String appId = (appid == null) || (appid == "") ? APP_ID : appid;
    SignResult result = new SignResult();
    AnyChatOutParam signResult = new AnyChatOutParam();

    int errorcode = AnyChatSign.RsaSign(-1, userName, appId, PRIVATE_KEY, signResult);
    if (errorcode == 0) {
      int timestamp = signResult.GetIntValue();
      String sigStr = signResult.GetStrValue();
      result.setErrorcode(errorcode);
      result.setTimestamp(timestamp);
      result.setSigStr(sigStr);
      result.setAppId(appid);
    }

    return result;
  }

  public static int verifySign(String userName, String sigstr, int timestamp, String appid) {
    String appId = (appid == null) || (appid == "") ? APP_ID : appid;
    return AnyChatSign.RsaVerify(-1, userName, appId, sigstr, timestamp, PUBLIC_KEY);
  }

  public static void main(String[] args) {
    String userName = "admin";
    String appid = "F7DCBA9C-4D7B-E84E-ADE2-E36189D64736";
    SignResult signResult = getRsaSign(userName, appid);
    System.out.println(userName+signResult);

    if (verifySign(userName, signResult.getSigStr(), signResult.getTimestamp(), appid) == 0)
      System.out.println("signature verify pass.");
  }

  public static boolean verifySignForMd5(String sign, String userid, String signtype, String timestamp, String appid)
    throws SignException
  {
    String signature = null;
    if (stringsHaveEmpty(new String[] { sign, userid, signtype, timestamp, appid })) {
      throw new SignException("PARAMETER FORMAT ERROR");
    }
    if (!timeIsOk(timestamp)) {
      throw new SignException("OVER TIME ERROR");
    }
    if (!signtype.equalsIgnoreCase("MD5")) {
      throw new SignException("ERROR SIGN TYPE");
    }
    if ((MD5_KEY == null) || ("".equals(MD5_KEY))) {
      throw new SignException("MD5 KEY NOT FOUND");
    }
    StringBuilder basestring = new StringBuilder();

    basestring.append(appid).append("&").append(timestamp).append("&").append(userid).append("&").append(MD5_KEY);
    try
    {
      signature = string2MD5(basestring.toString());
    } catch (Exception e) {
      throw new SignException("AUTHENTICATION FAILED");
    }
    if (signature.equalsIgnoreCase(sign)) {
      return true;
    }
    return false;
  }

  private static boolean timeIsOk(String timestamp) {
    if (OVER_TIME == 0) {
      return true;
    }
    SimpleDateFormat formater = new SimpleDateFormat("yyyyMMddHHmmss");
    long signTime = 0L;
    try {
      signTime = formater.parse(timestamp).getTime();
    } catch (ParseException e) {
      throw new SignException("TIMESTAMP PARSE FAIL");
    }

    long nowTime = new Date().getTime();

    if (nowTime - signTime < OVER_TIME * 1000) {
      return true;
    }

    return false;
  }

  private static String string2MD5(String inStr) throws Exception {
    MessageDigest md5 = MessageDigest.getInstance("MD5");
    byte[] md5Bytes = md5.digest(inStr.getBytes("ISO-8859-1"));
    StringBuffer hexValue = new StringBuffer();
    for (int i = 0; i < md5Bytes.length; i++) {
      int val = md5Bytes[i] & 0xFF;
      if (val < 16) {
        hexValue.append("0");
      }
      hexValue.append(Integer.toHexString(val));
    }
    return hexValue.toString();
  }

  public static boolean stringsHaveEmpty(String[] list)
  {
    if ((list == null) || (list.length < 1)) {
      return true;
    }
    for (int i = 0; i <= list.length - 1; i++) {
      String s = list[i];
      if ((s == null) || ("".equals(s))) {
        return true;
      }
    }
    return false;
  }
}