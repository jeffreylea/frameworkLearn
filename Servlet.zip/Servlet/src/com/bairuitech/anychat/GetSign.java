package com.bairuitech.anychat;

import java.io.*;
import javax.json.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

// Referenced classes of package com.bairuitech.anychat:
//            AnyChatSignUtils, SignResult

public class GetSign extends HttpServlet
{

    private static final long serialVersionUID = 0x2509e294b2d74c31L;

    public GetSign()
    {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        String userName = request.getParameter("struserid");
        String appid = request.getParameter("struserid");
        SignResult signResult = AnyChatSignUtils.getRsaSign(userName, appid);
        response.setCharacterEncoding("utf8");
        response.setContentType("application/json;charset=UTF-8");
        response.addHeader("Access-Control-Allow-Origin", "*");
        JsonObject obj = Json.createObjectBuilder().add("errorcode", signResult.getErrorcode()).add("timestamp", signResult.getTimestamp()).add("sigStr", signResult.getSigStr()).add("appId", signResult.getAppId()).build();
        PrintWriter out = response.getWriter();
        System.out.println(obj.toString());
        out.write(obj.toString());
        out.flush();
        out.close();
    }
}
