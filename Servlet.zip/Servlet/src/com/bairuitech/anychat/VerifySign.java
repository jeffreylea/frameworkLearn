package com.bairuitech.anychat;

import java.io.*;
import javax.json.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

// Referenced classes of package com.bairuitech.anychat:
//            AnyChatSignUtils, SignResult

public class VerifySign extends HttpServlet
{

    private static final long serialVersionUID = 0x9613c17ffb146486L;

    public VerifySign()
    {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        String userName = request.getParameter("userName");
        String appid = request.getParameter("appid");
        SignResult signResult = AnyChatSignUtils.getRsaSign(userName, appid);
        response.setCharacterEncoding("utf8");
        response.setContentType("application/json;charset=UTF-8");
        response.addHeader("Access-Control-Allow-Origin", "*");
        JsonObject obj = Json.createObjectBuilder().add("errorcode", signResult.getErrorcode()).add("timestamp", signResult.getTimestamp()).add("sigStr", signResult.getSigStr()).build();
        PrintWriter out = response.getWriter();
        System.out.println(obj.toString());
        out.write(obj.toString());
        out.flush();
        out.close();
    }
}
