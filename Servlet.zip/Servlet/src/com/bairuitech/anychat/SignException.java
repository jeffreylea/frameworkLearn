package com.bairuitech.anychat;


public class SignException extends RuntimeException
{

    private static final long serialVersionUID = 0x3eaf12615571dd9cL;
    private String msg;

    public SignException(String msg)
    {
        this.msg = msg;
    }

    public String getMsg()
    {
        return msg;
    }

    public void setMsg(String msg)
    {
        this.msg = msg;
    }
}
