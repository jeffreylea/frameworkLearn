package com.bairuitech.anychat;

import java.io.File;
import java.io.PrintStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class AnyChatSign
{
  static
  {
    System.out.println("java.library.path is " + System.getProperty("java.library.path"));
    try
    {
      String os = System.getProperty("os.name").toLowerCase();
      URI uri;
      if (os.indexOf("win") >= 0)
        uri = AnyChatSign.class.getResource("/anychatsign.dll").toURI();
      else {
        uri = AnyChatSign.class.getResource("/libanychatsign.so").toURI();
      }

      String realPath = new File(uri).getAbsolutePath();
      System.load(realPath);
    } catch (URISyntaxException e) {
      e.printStackTrace();
    }
  }

  public static native int RsaSign(int paramInt, String paramString1, String paramString2, String paramString3, AnyChatOutParam paramAnyChatOutParam);

  public static native int RsaVerify(int paramInt1, String paramString1, String paramString2, String paramString3, int paramInt2, String paramString4);
}