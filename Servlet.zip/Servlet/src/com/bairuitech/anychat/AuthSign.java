package com.bairuitech.anychat;

import java.io.*;
import javax.json.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

// Referenced classes of package com.bairuitech.anychat:
//            AnyChatSignUtils, SignException, SignResult

public class AuthSign extends HttpServlet
{

    private static final long serialVersionUID = 0xd2f937c4e1fc9232L;

    public AuthSign()
    {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        String userid = request.getParameter("userid");
        String signtype = request.getParameter("signtype");
        String signstr = request.getParameter("signstr");
        String timestamp = request.getParameter("timestamp");
        String appid = request.getParameter("appid");
        boolean flag = false;
        try
        {
            flag = AnyChatSignUtils.verifySignForMd5(signstr, userid, signtype, timestamp, appid);
        }
        catch(SignException e)
        {
            String return_msg = e.getMsg();
            response.setCharacterEncoding("utf8");
            response.setContentType("application/json;charset=UTF-8");
            response.addHeader("Access-Control-Allow-Origin", "*");
            response.setStatus(400);
            JsonObject obj = Json.createObjectBuilder().add("return_code", "FAIL").add("return_msg", return_msg).build();
            PrintWriter out = response.getWriter();
            System.out.println(obj.toString());
            out.write(obj.toString());
            out.flush();
            out.close();
            return;
        }
        if(flag)
        {
            SignResult signResult = AnyChatSignUtils.getRsaSign(userid, appid);
            response.setCharacterEncoding("utf8");
            response.setContentType("application/json;charset=UTF-8");
            response.addHeader("Access-Control-Allow-Origin", "*");
            
            JsonObject obj = Json.createObjectBuilder().add("return_code", "SUCCESS").add("return_msg", "").add("appId", signResult.getAppId()).add("userid", userid).add("sign_stamptime", signResult.getTimestamp()).add("sign_data", signResult.getSigStr()).build();
            PrintWriter out = response.getWriter();
            System.out.println(obj.toString());
            out.write(obj.toString());
            out.flush();
            out.close();
        } else
        {
            response.setCharacterEncoding("utf8");
            response.setContentType("application/json;charset=UTF-8");
            response.addHeader("Access-Control-Allow-Origin", "*");
            JsonObject obj = Json.createObjectBuilder().add("return_code", "FAIL").add("return_msg", "AUTHENTICATION_FAILED").build();
            PrintWriter out = response.getWriter();
            System.out.println(obj.toString());
            out.write(obj.toString());
            out.flush();
            out.close();
        }
    }
}
