package com.bairuitech.anychat;


public class AnyChatOutParam
{

    private int iValue;
    private String szValue;
    private int intArray[];
    private byte byteArray[];
    private double fValue;

    public AnyChatOutParam()
    {
        iValue = 0;
        szValue = "";
        fValue = 0.0D;
    }

    public int GetIntValue()
    {
        return iValue;
    }

    public void SetIntValue(int v)
    {
        iValue = v;
    }

    public double GetFloatValue()
    {
        return fValue;
    }

    public void SetFloatValue(double f)
    {
        fValue = f;
    }

    public String GetStrValue()
    {
        return szValue;
    }

    public void SetStrValue(String s)
    {
        szValue = s;
    }

    public int[] GetIntArray()
    {
        return intArray;
    }

    public void SetIntArray(int a[])
    {
        intArray = a;
    }

    public byte[] GetByteArray()
    {
        return byteArray;
    }

    public void SetByteArray(byte b[])
    {
        byteArray = b;
    }
}
