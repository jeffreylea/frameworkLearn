package com.bairuitech.anychat;

import java.io.PrintStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Example
{

    public Example()
    {
    }

    public static void main(String args[])
    {
        String yyyyMMddHHmmss = (new SimpleDateFormat("yyyyMMddHHmmss")).format(new Date());
        StringBuilder basestring = new StringBuilder();
        basestring.append("F7DCBA9C-4D7B-E84E-ADE2-E36189D64736").append("&").append(yyyyMMddHHmmss).append("&").append("su").append("&").append("8razoc60849tqgx3ki08i7hjpfo2djw6");
        String signature = null;
        try
        {
            signature = string2MD5(basestring.toString());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        System.out.println((new StringBuilder("signature:")).append(signature).toString());
        System.out.println((new StringBuilder("url:http://localhost:8080/AnyChatSignDemo/auth_sign?userid=su&signtype=MD5&signs" +
"tr="
)).append(signature).append("&timestamp=").append(yyyyMMddHHmmss).append("&appid=").append("F7DCBA9C-4D7B-E84E-ADE2-E36189D64736").toString());
    }

    private static String string2MD5(String inStr)
        throws Exception
    {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        byte md5Bytes[] = md5.digest(inStr.getBytes("ISO-8859-1"));
        StringBuffer hexValue = new StringBuffer();
        for(int i = 0; i < md5Bytes.length; i++)
        {
            int val = md5Bytes[i] & 0xff;
            if(val < 16)
            {
                hexValue.append("0");
            }
            hexValue.append(Integer.toHexString(val));
        }

        return hexValue.toString();
    }
}
